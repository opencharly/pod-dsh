/**
 * REQ-I18: carry one call's sandbox policy from the shell executor into
 * `subprocess.spawn`.
 *
 * Official bash/pwsh approve `sandbox_permissions` and stamp the granted mode
 * onto the shell spec. `SubprocessSpawnSpec` has no policy field, and a
 * danger grant never calls `confine`, so the remote core used to keep the
 * sticky session mode. This store is entered around `ctx.shell.run` / `start`
 * (and around our own `sw_exec` / win32 bash spawns) and read once, synchronously,
 * inside `SshSubprocessEngine.spawn`.
 *
 * @module dsh-workspace-enhancement/remote-spawn-policy
 */
import type { Context } from '@deepseek-ai/cordis';
/** True only inside a host-local shell call (`dswLocalExec`). */
export declare function isHostLocalShellExec(): boolean;
/** The policy bound to the current spawn, if a caller entered one. */
export declare function currentRemoteSpawnPolicy(): unknown;
/**
 * Run `fn` with `policy` visible to {@link currentRemoteSpawnPolicy}.
 * `undefined` does not enter the store, so a non-escalated call keeps the
 * session mode.
 */
export declare function runWithRemoteSpawnPolicy<T>(policy: unknown, fn: () => T): T;
interface ShellSpec {
    sandboxPolicy?: unknown;
    workdir?: string;
    /** Set by `sw_exec(server: "local")` so the pin does not send it remote. */
    dswLocalExec?: boolean;
    [key: string]: unknown;
}
/**
 * Pin the official shell to its world (ADR-0028). Windows `ctx.shell` is pwsh:
 * a remote spelling stays on this host. Linux `ctx.shell` is bash: a remote
 * main workspace rejects local paths and other machines. `dswLocalExec` is the
 * Linux `sw_exec(server: "local")` bypass and is stripped before the executor.
 */
export declare function adjustShellSpec(ctx: Context, spec: ShellSpec): ShellSpec;
/**
 * Bind `ctx.shell` run/start so the spec's `sandboxPolicy` is visible to the
 * remote spawn they perform. Safe when `shell` is not provided yet.
 */
export declare function installRemoteSpawnPolicyBridge(ctx: Context): void;
export {};
