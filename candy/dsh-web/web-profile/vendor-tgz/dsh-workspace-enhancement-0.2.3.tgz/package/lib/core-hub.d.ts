/**
 * REQ-I5 / ADR-0024: live `dsh-core serve` cache.
 *
 * Key is `(machineId, confinementMode, workspaceRoot?)` — not "one process
 * per SSH connection". `off` (session danger-full-access) is one unjailed
 * serve per machine. A dead session is fail-closed for confined **writes and
 * spawn**; REQ-I15 lets confined **reads** fall back to SFTP. danger may fall
 * back to SFTP via {@link CoreMissingError}.
 *
 * @module dsh-workspace-enhancement/core-hub
 */
import type { Context } from '@deepseek-ai/cordis';
import { CoreClient } from './core-client.ts';
import { CORE_REMOTE_HOME } from './core-protocol.ts';
import { CORE_IDLE_MS } from './core-session.ts';
import type { SandboxMode } from '@deepseek-ai/dsh-sandbox';
import type { RemoteSandboxDeps } from './remote-sandbox-fence.ts';
import type { CoreServeSandbox } from './remote-policy.ts';
import type { RemoteSandboxMode } from './remote-sandbox.ts';
import type { SshTransport } from './transport.ts';
export interface CoreStatusView {
    ok: boolean;
    version?: string | undefined;
    arch?: string | undefined;
    proto?: number | undefined;
    caps?: readonly string[] | undefined;
    sandbox?: RemoteSandboxMode | undefined;
    detail?: string | undefined;
}
export interface CoreOpenRequest {
    connectionId: string;
    mode: CoreServeSandbox;
    workspace?: string | undefined;
    signal?: AbortSignal | undefined;
    transport: SshTransport;
}
export type CoreSessionOpener = (request: CoreOpenRequest) => Promise<CoreClient>;
/**
 * REQ-I14 first-use approval: the hub asks this once when a **confined** open
 * fails and the ON-DISK artifact is verifiably missing or stale. Resolving
 * `true` means "the matching core is deployed now; retry the open" — the hub
 * then re-execs `current` exactly once. Any other ending (no approval service,
 * denied, deploy failed) falls through to the original fail-closed error.
 */
export type CoreGapResolver = (connectionId: string, facts: {
    /** Disk-reported core version; `undefined` when no core answered. */
    found: string | undefined;
    /** The version this plugin ships and requires. */
    expected: string;
    /** Cancellation lifetime of the blocked operation, when one exists. */
    signal?: AbortSignal | undefined;
}) => Promise<boolean>;
export interface CoreRequireOpts {
    /** Session / spawn cwd — may mint a sibling workspace-write jail. */
    cwd?: string | undefined;
    /** Operation path (fs target, browse listing) — match only, never mint. */
    path?: string | undefined;
    signal?: AbortSignal | undefined;
    /** Session `/permission` (or escalation overlay). Absent → resolve from ctx. */
    policy?: SandboxMode | undefined;
}
export interface CoreHub {
    modeOf(connectionId: string | undefined): RemoteSandboxMode;
    require(connectionId: string, opts?: CoreRequireOpts): Promise<CoreClient>;
    peek(connectionId: string, opts?: CoreRequireOpts): CoreClient | undefined;
    /** Keep the matching serve off the idle timer until the disposer runs (spawn jobs). */
    hold(connectionId: string, opts?: CoreRequireOpts): () => void;
    status(connectionId: string, signal?: AbortSignal): Promise<CoreStatusView>;
    close(connectionId: string): void;
}
/** Shell command that execs the installed core in the login user's home. */
export declare function coreServeCommand(mode: CoreServeSandbox, workspace?: string): string;
export declare function coreVersionCommand(): string;
/** On-disk binary hash probe for the REQ-I17 provenance gate. */
export declare function coreBinaryHashCommand(): string;
/** Whether a hashed binary is one this plugin shipped (the compat list). */
export declare function isKnownCoreBinary(hash: string | undefined): boolean;
export declare function coreArtifactName(): string;
/**
 * Build the hub. Tests inject `open` (a fake client); production uses SSH exec.
 * `idleMs: 0` disables idle-kill (unit tests that would otherwise pin the event loop).
 */
export declare function createCoreHub(ctx: Context, options?: {
    deps?: RemoteSandboxDeps;
    open?: CoreSessionOpener;
    statusOf?: (connectionId: string, signal?: AbortSignal) => Promise<CoreStatusView>;
    idleMs?: number;
    /** REQ-I14: approval-backed core deploy on a confined open's missing/stale gap. */
    resolveGap?: CoreGapResolver;
}): CoreHub;
export declare function coreUnavailable(detail: string): never;
/**
 * Return the process-wide hub when the plugin fiber has provided it.
 * Callers that must not create a service (picker tests, tool stubs) use this.
 */
export declare function coreHubOf(ctx: Context): CoreHub | undefined;
/**
 * Return the process-wide hub, creating and `ctx.provide`-ing it on first use
 * so the aggregate row, the web channel, and the directory picker share one
 * session cache. Effect-bound: unloading the row drops the name.
 *
 * The production hub carries the REQ-I14 first-use approval resolver (ask the
 * platform approval service, deploy, retry once); tests that build their own
 * hub via {@link createCoreHub} stay resolver-free.
 */
export declare function ensureCoreHub(ctx: Context): CoreHub;
export { CORE_REMOTE_HOME, CORE_IDLE_MS };
