/**
 * REQ-I13 / ADR-0025: wrap `ctx.sandbox.confine` so a remote initiator cwd
 * does not get a *local* bwrap/landlock runner stuffed into argv.
 *
 * Official bash/fs escalation happens *before* confine. This passthrough only
 * skips host wrapping; it does not skip the approval card.
 *
 * @module dsh-workspace-enhancement/remote-confine
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ConfinedArgv } from '@deepseek-ai/dsh-sandbox';
/**
 * Remote core jail is bubblewrap. Official bash classifies a denial only when
 * `confine` advertises this dialect (`Read-only file system` on stderr).
 */
export declare const REMOTE_CORE_DENIAL_SIGNATURE = "read-only file system";
/** Non-zero exit whose stderr matches the remote bwrap denial dialect. */
export declare function isRemoteCommandDenial(exitCode: number | null, stderr: string): boolean;
/**
 * Identity argv for a remote session: the host runner must not wrap the
 * command, but the denial dialect stays the remote core's bwrap text so
 * official bash/pwsh still append the escalation hint.
 */
export declare function passthroughConfinedArgv(argv: readonly string[]): ConfinedArgv;
/**
 * True when the current initiator session's cwd is a remote route (`ssh://`
 * or a placeholder tree). Missing initiator → false (local is the safe default).
 */
export declare function shouldPassthroughRemoteConfine(ctx: Context): boolean;
/**
 * Install the remote-cwd confine short-circuit on the live `sandbox` service.
 * Safe to call when the name is not yet provided (`inject` waits).
 */
export declare function installRemoteConfinePassthrough(ctx: Context): void;
