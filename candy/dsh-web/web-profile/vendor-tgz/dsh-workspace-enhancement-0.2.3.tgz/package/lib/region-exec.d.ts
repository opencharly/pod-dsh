/**
 * REQ-I19 / ADR-0028: which tool owns which world, and the cwd that decision
 * implies. Model-facing refusals are English constants (ADR-0014), not locale
 * strings — a Chinese UI must not change what the model is told to retry with.
 *
 * @module dsh-workspace-enhancement/region-exec
 */
/** Reserved machine id. `sw_exec(server: "local")` is not a registry row. */
export declare const LOCAL_SERVER_ID = "local";
export declare const SW_EXEC_USE_BASH = "sw_exec: this session's remote workspace uses the bash tool. Retry with bash, not sw_exec.";
export declare const SW_EXEC_USE_PWSH = "sw_exec: local commands use the pwsh tool. Retry with pwsh, not sw_exec.";
export declare const SW_EXEC_USE_LOCAL_BASH = "sw_exec: local commands use the bash tool. Retry with bash, not sw_exec.";
export declare const SW_EXEC_WORLD_CONFLICT = "sw_exec: server and workdir name different worlds. Use a remote workdir with a remote server, or server \"local\" with a local absolute path.";
export declare const SW_EXEC_LOCAL_WORKDIR = "sw_exec: a local workdir must be an absolute path on this host.";
export declare const SW_EXEC_LOCAL_SHELL_MISSING = "sw_exec: local execution needs the host bash shell, which is not mounted.";
export declare const SW_EXEC_LOCAL_START_MISSING = "sw_exec: local background needs the host shell start, which is not mounted.";
export declare const BASH_USE_SW_EXEC = "bash: workdir names another machine. Use sw_exec for that server.";
export declare const BASH_USE_LOCAL = "bash: this tool is pinned to the remote workspace. On Linux, local paths use sw_exec with server \"local\".";
export declare const BASH_USE_SW_EXEC_LOCAL_SESSION = "bash: this session is local. Remote commands use sw_exec.";
export type SwExecDecision = {
    action: 'remote';
} | {
    action: 'local';
} | {
    action: 'refuse';
    message: string;
};
export interface SwExecDecisionInput {
    platform: NodeJS.Platform;
    /** Machine of the session's main workspace, when that workspace is remote. */
    sessionMachineId: string | undefined;
    /** Trimmed `server` argument, or `undefined` when the model omitted it. */
    requestedServer: string | undefined;
    /** Raw `workdir` argument, before remote normalization. */
    workdir: string | undefined;
}
/** Whether `id` is the reserved local sentinel (must not be stored as a machine). */
export declare function isReservedLocalServer(id: string | undefined): boolean;
/**
 * Cwd for `pwsh` and `sw_exec(server: "local")` when the main workspace is
 * remote. Exactly one local side root wins; zero or many use the home
 * directory. This does not add that root to the sandbox writable set.
 */
export declare function sessionLocalCwd(localSideRoots: readonly string[], home?: string): string;
/**
 * A workdir the model spelled as this host's filesystem, not a remote route.
 * Relative paths are neither: they follow the session workspace.
 */
export declare function isLocalWorkdirSpelling(workdir: string | undefined, platform: NodeJS.Platform): boolean;
/**
 * Route one `sw_exec` call. Refusals name the tool the model should retry
 * with. They do not rewrite the call into that tool.
 */
export declare function decideSwExec(input: SwExecDecisionInput): SwExecDecision;
/**
 * Official bash on a Linux host. A remote main workspace stays on that
 * machine; a local main workspace stays local. The other world is a refusal,
 * not a silent reroute.
 * @returns the workdir to keep (possibly unchanged).
 */
export declare function pinBashWorkdir(workdir: string | undefined, sessionCwd: string | undefined): string | undefined;
/**
 * Official pwsh on a Windows host. A remote spelling (ssh, placeholder, bare
 * POSIX) is not sent to the remote machine; the call keeps running locally
 * at {@link sessionLocalCwd}.
 */
export declare function pinPwshWorkdir(workdir: string | undefined, localCwd: string): string | undefined;
