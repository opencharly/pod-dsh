/**
 * Model-facing tool schemas — ENGLISH ONLY (UX-6 / ADR-0014).
 *
 * Official bash/pwsh schemas are hardcoded English. These descriptions and
 * parameter texts match that: they do not follow the settings Language row.
 * Execution errors and rendered tool output stay in `src/locale/`.
 *
 * @module dsh-workspace-enhancement/tool-schema
 */
import type { ParameterSchemaSpec } from '@deepseek-ai/dsh-tools';
export declare const SW_STATUS_DESCRIPTION = "Show the current remote machine (host/user/port), connection health (ping), the current remote workspace (from the session cwd / machine record, not a model tool), and the host-key policy/state. Call this first to orient, or when an sw_* call fails to check connectivity.";
export declare const SW_CONNECT_DESCRIPTION = "Set which registered machines this session may connect to and run commands on. Every call REPLACES the whole set (it is not a union): `machines: []` disconnects everything. Does not choose a workspace directory (that is the session cwd / add-workspace flow). Machines must be ids of registered machines; an unknown id errors with the known list. Each requested machine is then pinged within a bounded budget: reachable ones are recorded as connected, unreachable ones are reported honestly and left out; when none is reachable the call fails and the existing connections stay unchanged.";
export declare function swExecDescription(backgroundEnabled: boolean): string;
export declare function bashDescription(backgroundEnabled: boolean): string;
/** Shared escalation fields. Advertised whenever the tool can confine a remote command. */
export declare function escalationParams(): {
    readonly sandbox_permissions: {
        readonly type: "string";
        readonly enum: readonly ["workspace-write", "danger-full-access"];
        readonly description: "The wider sandbox mode this command needs. Only valid as a one-shot retry of a command the sandbox just denied; requires justification and user approval.";
    };
    readonly justification: {
        readonly type: "string";
        readonly description: "Required with sandbox_permissions: one sentence for the user explaining why this exact command needs the wider access.";
    };
};
export declare const SW_CONNECT_PARAMS: ParameterSchemaSpec;
export declare function swExecParams(backgroundEnabled: boolean): {
    sandbox_permissions: {
        readonly type: "string";
        readonly enum: readonly ["workspace-write", "danger-full-access"];
        readonly description: "The wider sandbox mode this command needs. Only valid as a one-shot retry of a command the sandbox just denied; requires justification and user approval.";
    };
    justification: {
        readonly type: "string";
        readonly description: "Required with sandbox_permissions: one sentence for the user explaining why this exact command needs the wider access.";
    };
    run_in_background?: {
        type: "boolean";
        description: string;
    };
    command: {
        type: "string";
        required: true;
        description: string;
    };
    description: {
        type: "string";
        required: true;
        description: string;
    };
    timeoutMs: {
        type: "number";
        description: string;
    };
    workdir: {
        type: "string";
        description: string;
    };
    server: {
        type: "string";
        description: string;
    };
};
export declare function bashParams(backgroundEnabled: boolean): {
    sandbox_permissions: {
        readonly type: "string";
        readonly enum: readonly ["workspace-write", "danger-full-access"];
        readonly description: "The wider sandbox mode this command needs. Only valid as a one-shot retry of a command the sandbox just denied; requires justification and user approval.";
    };
    justification: {
        readonly type: "string";
        readonly description: "Required with sandbox_permissions: one sentence for the user explaining why this exact command needs the wider access.";
    };
    run_in_background?: {
        type: "boolean";
        description: string;
    };
    command: {
        type: "string";
        required: true;
        description: string;
    };
    description: {
        type: "string";
        required: true;
        description: string;
    };
    timeoutMs: {
        type: "number";
        description: string;
    };
    workdir: {
        type: "string";
        description: string;
    };
};
