/**
 * `/worktree` human command surface. Destructive verbs are intentionally
 * user-initiated; model tools stop at Ready for Review.
 * @module dsh-git-worktree/commands
 */
import type { Context } from '@deepseek-ai/cordis';
import '@deepseek-ai/dsh-commands';
import type { SessionCheckoutModule } from './index.js';
/** Register the `/worktree` command. */
export declare function registerWorktreeCommand(ctx: Context, module: SessionCheckoutModule): void;
