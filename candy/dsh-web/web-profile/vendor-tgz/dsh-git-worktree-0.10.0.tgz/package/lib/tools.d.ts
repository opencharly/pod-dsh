import type { Context } from '@deepseek-ai/cordis';
import type { SessionCheckoutModule } from './index.js';
/** Register the safe model-facing worktree tools. */
export declare function registerTools(ctx: Context, module: SessionCheckoutModule): void;
