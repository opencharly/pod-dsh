export type WorkspaceClientFlavor = 'legacy' | 'alpha' | 'next' | 'modern' | 'unsupported';
export declare function workspaceClientFlavorForAgentVersion(version: string | undefined): WorkspaceClientFlavor;
/** The Host-resolved agent package is a version signal, not the plugin's build-time dev dependency. */
export declare function hostWorkspaceClientFlavor(): WorkspaceClientFlavor;
