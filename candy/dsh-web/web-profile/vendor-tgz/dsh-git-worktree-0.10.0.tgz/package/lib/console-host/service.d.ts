import type { Language } from '../i18n/core.js';
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { WorktreeConsoleCreatePreviewRecoveryHandoffResponse, WorktreeConsoleCreateResponse, WorktreeConsoleCreatePreflightResponse, WorktreeConsoleCurrentResponse, WorktreeConsoleInspectResponse, WorktreeConsoleListResponse, WorktreeConsoleMutationResponse, WorktreeConsoleOutcome, WorktreeConsolePreflightResponse, WorktreeConsolePreviewRecoveryPreflightResponse, WorktreeConsoleReviewDiffResponse, WorktreeApplyConflictContinuation, WorktreeSidebarTopologyResponse } from '../console-contract.js';
import type { WorktreePreviewRecoveryProof, WorktreeRetentionMode } from '../types.js';
import type { WorktreeConsoleControlPlane } from './control-plane.js';
/** Official Typert Remote service; the Gateway resolves `agentId` before business code runs. */
export declare class WorktreeConsoleService extends TypertRemoteService {
    private readonly hostContext;
    private readonly controlPlane;
    constructor(hostContext: Context, controlPlane: WorktreeConsoleControlPlane);
    sidebarTopology(locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeSidebarTopologyResponse>>;
    current(agent: Agent, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleCurrentResponse>>;
    list(agent: Agent, needsAttention?: boolean, includeDelivered?: boolean, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleListResponse>>;
    preflightCreate(agent: Agent, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreatePreflightResponse>>;
    createWithInitialCommit(agent: Agent, confirmationToken: string, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreateResponse>>;
    create(agent: Agent, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreateResponse>>;
    inspect(agent: Agent, checkoutId: string, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleInspectResponse>>;
    reviewDiff(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleReviewDiffResponse>>;
    preflight(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsolePreflightResponse>>;
    previewRecoveryPreflight(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, expectedPreviewId: string, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsolePreviewRecoveryPreflightResponse>>;
    preparePreviewRecoveryAnalysis(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, expectedPreviewId: string, recoveryProof: WorktreePreviewRecoveryProof, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    createPreviewRecoveryHandoff(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, expectedPreviewId: string, recoveryProof: WorktreePreviewRecoveryProof, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreatePreviewRecoveryHandoffResponse>>;
    preview(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    checkpoint(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, expectedGeneration: string, requestId: string, commitMessage: string, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    prepareReviewRegeneration(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    resumeRevision(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, conflictContinuation?: WorktreeApplyConflictContinuation, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    rollbackPreview(agent: Agent, checkoutId: string, expectedRevision: number, resumeRevision?: boolean, recoveryProof?: WorktreePreviewRecoveryProof, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    discard(agent: Agent, checkoutId: string, expectedRevision: number, confirmDirty: boolean, rollbackPreview?: boolean, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    finalize(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, commitMessage: string, retention: WorktreeRetentionMode, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    finalizePreview(agent: Agent, checkoutId: string, expectedRevision: number, expectedReviewId: string, commitMessage: string, retention: WorktreeRetentionMode, recoveryProof?: WorktreePreviewRecoveryProof, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    setRetention(agent: Agent, checkoutId: string, expectedRevision: number, retention: Exclude<WorktreeRetentionMode, 'cleanup'>, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    retryCleanup(agent: Agent, checkoutId: string, expectedRevision: number, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    beginNextIteration(agent: Agent, checkoutId: string, expectedRevision: number, locale?: Language): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
}
