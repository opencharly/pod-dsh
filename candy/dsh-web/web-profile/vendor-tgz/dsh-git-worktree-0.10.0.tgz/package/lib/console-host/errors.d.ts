import { type SessionCheckoutErrorCode } from '../types.js';
import type { WorktreeConsoleError, WorktreeConsoleOutcome } from '../console-contract.js';
export declare function domainError(code: SessionCheckoutErrorCode, message: string, continuation?: WorktreeConsoleError['continuation']): Error;
export declare function consoleFailure(error: unknown): WorktreeConsoleOutcome<never>;
export declare function failure<T>(code: WorktreeConsoleError['code'], message: string, details?: WorktreeConsoleError['details'], continuation?: WorktreeConsoleError['continuation']): WorktreeConsoleOutcome<T>;
export declare function outcome<T>(operation: () => Promise<T>): Promise<WorktreeConsoleOutcome<T>>;
