import { type WorktreeConsoleCapabilities, type WorktreeConsoleDeliveryProof, type WorktreeConsoleTargetDetails, type WorktreeConsoleTargetSummary } from '../console-contract.js';
import type { GitCheckoutSnapshot, ManagedCheckoutRecord } from '../ports.js';
import type { ManagedWorktreeSummaryView, SessionTargetView } from '../types.js';
export declare function capabilities(record: ManagedCheckoutRecord, callerSessionId: string, ownerSessionAvailable?: boolean, linkedRead?: boolean): WorktreeConsoleCapabilities;
export declare function projectRecord(record: ManagedCheckoutRecord, callerSessionId: string, observed?: {
    snapshot?: GitCheckoutSnapshot;
    dirty?: boolean;
    summary?: ManagedWorktreeSummaryView;
    ownerSessionAvailable?: boolean;
    linkedRead?: boolean;
    deliveryProof?: WorktreeConsoleDeliveryProof;
}): WorktreeConsoleTargetSummary;
export declare function projectDetails(record: ManagedCheckoutRecord, callerSessionId: string, managedRoot: string | null, snapshot?: GitCheckoutSnapshot, dirty?: boolean, ownerSessionAvailable?: boolean, linkedRead?: boolean, observedDeliveryProof?: WorktreeConsoleDeliveryProof): WorktreeConsoleTargetDetails;
export declare function projectLocal(target: SessionTargetView, sessionId: string): WorktreeConsoleTargetDetails;
