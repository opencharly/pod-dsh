import { type ProjectSkillStore } from '../adapters/project-skills.js';
import type { WorktreeConsoleReviewDiffResponse } from '../console-contract.js';
export declare const REVIEW_DIFF_MAX_FILES = 200;
export declare const REVIEW_DIFF_MAX_PATCH_BYTES: number;
export declare const REVIEW_DIFF_MAX_PAYLOAD_BYTES: number;
export interface ReviewDiffReadInput {
    managedRoot: string;
    baseOid: string;
    reviewId: string;
    revision: number;
    changedFiles: readonly string[];
}
export interface WorktreeReviewDiffReader {
    read(input: ReviewDiffReadInput): Promise<WorktreeConsoleReviewDiffResponse>;
}
export declare class ReviewDiffStaleError extends Error {
    constructor(message: string);
}
export declare function createGitWorktreeReviewDiffReader(projectSkills?: ProjectSkillStore): WorktreeReviewDiffReader;
