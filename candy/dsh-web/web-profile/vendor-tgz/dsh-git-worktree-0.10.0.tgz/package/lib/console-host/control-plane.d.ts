import type { WorktreeConsoleBeginNextIterationRequest, WorktreeConsoleCreatePreviewRecoveryHandoffRequest, WorktreeConsoleCreatePreviewRecoveryHandoffResponse, WorktreeConsoleCreateResponse, WorktreeConsoleCreatePreflightResponse, WorktreeConsoleCheckpointRequest, WorktreeConsoleCurrentResponse, WorktreeConsoleDiscardRequest, WorktreeConsoleFinalizePreviewRequest, WorktreeConsoleFinalizeRequest, WorktreeConsoleInspectResponse, WorktreeConsoleListRequest, WorktreeConsoleListResponse, WorktreeConsoleMutationResponse, WorktreeConsoleOutcome, WorktreeConsolePreflightRequest, WorktreeConsolePreflightResponse, WorktreeConsolePreparePreviewRecoveryAnalysisRequest, WorktreeConsolePreviewRecoveryPreflightRequest, WorktreeConsolePreviewRecoveryPreflightResponse, WorktreeConsolePrepareRegenerationRequest, WorktreeConsolePreviewRequest, WorktreeConsoleResumeRevisionRequest, WorktreeConsoleRollbackPreviewRequest, WorktreeConsoleRetryCleanupRequest, WorktreeConsoleReviewDiffRequest, WorktreeConsoleReviewDiffResponse, WorktreeConsoleSetRetentionRequest, WorktreeSidebarTopologyResponse } from '../console-contract.js';
import type { SessionCheckoutFilesPort, SessionCheckoutGitPort, SessionCheckoutLookupPort, SessionCheckoutRegistryPort } from '../ports.js';
import type { SessionCheckoutModule } from '../index.js';
import { type WorktreeReviewDiffReader } from './review-diff.js';
export interface WorktreeConsoleControlPlaneOptions {
    module: SessionCheckoutModule;
    lookup: SessionCheckoutLookupPort;
    files: SessionCheckoutFilesPort;
    registry: SessionCheckoutRegistryPort;
    git: SessionCheckoutGitPort;
    reviewDiff: WorktreeReviewDiffReader;
    createTargetSessionId?: () => string;
}
export interface WorktreeConsoleControlPlane {
    sidebarTopology(): Promise<WorktreeConsoleOutcome<WorktreeSidebarTopologyResponse>>;
    current(sessionId: string): Promise<WorktreeConsoleOutcome<WorktreeConsoleCurrentResponse>>;
    list(request: WorktreeConsoleListRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleListResponse>>;
    preflightCreate(sourceSessionId: string): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreatePreflightResponse>>;
    createWithInitialCommit(sourceSessionId: string, confirmationToken: string): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreateResponse>>;
    create(sourceSessionId: string): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreateResponse>>;
    inspect(sessionId: string, checkoutId: string): Promise<WorktreeConsoleOutcome<WorktreeConsoleInspectResponse>>;
    reviewDiff(request: WorktreeConsoleReviewDiffRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleReviewDiffResponse>>;
    preflight(request: WorktreeConsolePreflightRequest): Promise<WorktreeConsoleOutcome<WorktreeConsolePreflightResponse>>;
    previewRecoveryPreflight(request: WorktreeConsolePreviewRecoveryPreflightRequest): Promise<WorktreeConsoleOutcome<WorktreeConsolePreviewRecoveryPreflightResponse>>;
    preparePreviewRecoveryAnalysis(request: WorktreeConsolePreparePreviewRecoveryAnalysisRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    createPreviewRecoveryHandoff(request: WorktreeConsoleCreatePreviewRecoveryHandoffRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreatePreviewRecoveryHandoffResponse>>;
    preview(request: WorktreeConsolePreviewRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    checkpoint(request: WorktreeConsoleCheckpointRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    resumeRevision(request: WorktreeConsoleResumeRevisionRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    prepareReviewRegeneration(request: WorktreeConsolePrepareRegenerationRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    rollbackPreview(request: WorktreeConsoleRollbackPreviewRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    discard(request: WorktreeConsoleDiscardRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    finalize(request: WorktreeConsoleFinalizeRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    finalizePreview(request: WorktreeConsoleFinalizePreviewRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    setRetention(request: WorktreeConsoleSetRetentionRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    retryCleanup(request: WorktreeConsoleRetryCleanupRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    beginNextIteration(request: WorktreeConsoleBeginNextIterationRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
}
export declare function createWorktreeConsoleControlPlane(options: WorktreeConsoleControlPlaneOptions): WorktreeConsoleControlPlane;
