/** A creation failure is not permission to infer that an empty-looking path is safe. */
export declare class WorktreeCreationFailure extends Error {
    readonly rolledBack: boolean;
    constructor(message: string, rolledBack: boolean);
}
