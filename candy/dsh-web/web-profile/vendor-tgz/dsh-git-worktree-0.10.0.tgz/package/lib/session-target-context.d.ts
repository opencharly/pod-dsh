/** Dynamic replay-stable model context for the current Worktree Session Target. */
import type { Context } from '@deepseek-ai/cordis';
import '@deepseek-ai/dsh-system-prompt';
import type { SessionCheckoutModule } from './index.js';
/** Register a per-assembly snapshot without performing Git or filesystem I/O. */
export declare function registerSessionTargetContext(ctx: Context, module: SessionCheckoutModule): void;
