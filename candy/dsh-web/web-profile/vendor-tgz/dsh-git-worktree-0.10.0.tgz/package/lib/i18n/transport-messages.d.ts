export declare const transportMessages: {
    readonly malformed: {
        readonly zh: "Remote {method} 返回了不符合 strict contract 的 payload";
        readonly en: "Remote {method} returned a payload that does not match the strict contract";
    };
    readonly mountFailed: {
        readonly zh: "Worktree Console Remote namespace 挂载失败";
        readonly en: "Failed to mount the Worktree Console Remote namespace";
    };
};
