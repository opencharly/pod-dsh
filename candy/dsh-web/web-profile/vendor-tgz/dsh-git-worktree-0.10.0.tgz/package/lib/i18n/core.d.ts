/** Shared translation primitives; never imports browser or Host-only modules. */
export type Language = 'zh' | 'en';
export declare function normalizeLanguage(value: unknown): Language;
export type MessageCatalog = Record<string, {
    readonly zh: string;
    readonly en: string;
}>;
type Placeholders<S extends string> = S extends `${string}{${infer P}}${infer Rest}` ? P | Placeholders<Rest> : never;
type MessageArgs<S extends string> = [Placeholders<S>] extends [never] ? [params?: Record<string, string | number>] : [params: Record<Placeholders<S>, string | number>];
export type Translator<C extends MessageCatalog> = <K extends keyof C & string>(key: K, ...args: MessageArgs<C[K]['zh'] | C[K]['en']>) => string;
export declare function createTranslator<const C extends MessageCatalog>(catalog: C, language: Language): Translator<C>;
export {};
