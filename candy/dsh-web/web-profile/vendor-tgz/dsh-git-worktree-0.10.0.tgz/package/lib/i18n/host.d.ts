import { type Language, type Translator } from './core.js';
import { hostMessages } from './host-messages.js';
export declare function currentHostLanguage(): Language;
export declare function withHostLanguage<T>(language: unknown, operation: () => T): T;
/** Read only the public, context-owned DSH settings seam; never persist browser preferences. */
export declare function languageFromSettings(ctx: unknown): Language;
/** Prefer the invocation's Agent context so scoped settings do not leak between users. */
export declare function languageForInvocation(agent: unknown, fallbackContext: unknown): Language;
export declare const hostMessage: Translator<typeof hostMessages>;
