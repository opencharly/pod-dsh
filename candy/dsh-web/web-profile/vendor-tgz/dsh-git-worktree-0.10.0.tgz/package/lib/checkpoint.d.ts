import type { ManagedCheckoutRecord } from './ports.js';
/** Host-derived CAS generation for the exact active Review and checkpoint chain. */
export declare function checkpointGenerationForRecord(record: ManagedCheckoutRecord): string | undefined;
