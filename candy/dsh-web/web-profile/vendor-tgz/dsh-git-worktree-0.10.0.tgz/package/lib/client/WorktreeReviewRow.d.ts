import type { WorktreeConsoleAdapter } from '../console-contract.js';
import type { WorktreeClientServices } from './actions.js';
import { type ToolCallViewPropsLike } from './model.js';
interface Props extends ToolCallViewPropsLike {
    /** Kept for the current Client registrar and historical ToolView compatibility. */
    services: WorktreeClientServices;
    /** Optional live Remote seam; logged evidence remains replayable without it. */
    adapter?: WorktreeConsoleAdapter;
}
export declare function WorktreeReviewRow({ block, sessionId, adapter }: Props): import("react").JSX.Element | null;
export {};
