import { type ClientTranslator } from '../i18n.js';
import type { WorktreeSidebarTask, WorktreeSidebarTopologyResponse } from '../../console-contract.js';
export interface SidebarWorkspaceView {
    workspaceId: string;
    title: string;
    path: string;
    sessionIds: readonly string[];
}
export interface SidebarSessionSummary {
    id: string;
    displayTitle: string;
    title?: string;
    cwd?: string;
    updatedAt?: number;
    blank?: boolean;
}
export interface ProjectedManagedTask extends WorktreeSidebarTask {
    projectId: string;
    projectName: string;
    label: string;
}
export interface ManagedWorkspaceSidebarProjection {
    workspaces: SidebarWorkspaceView[];
    managedBySessionId: Record<string, ProjectedManagedTask | undefined>;
    protectedSessionIds: ReadonlySet<string>;
    protectedWorkspaceIds: ReadonlySet<string>;
    relocatedSessionIds: ReadonlySet<string>;
    suppressedSessionIds: ReadonlySet<string>;
}
/**
 * Merge one owner Session per Managed Checkout into the original Local project.
 * Ambiguous Workspace membership fails open: the official Workspace rows remain
 * visible rather than hiding a Session the projection cannot prove safe.
 */
export declare function projectManagedWorkspaceSidebar(input: {
    workspaces: readonly SidebarWorkspaceView[];
    sessions: Readonly<Record<string, SidebarSessionSummary | undefined>>;
    topology: WorktreeSidebarTopologyResponse;
    archivedSessionIds?: readonly string[];
    currentSessionId?: string;
}, t?: ClientTranslator): ManagedWorkspaceSidebarProjection;
