import type { Context } from '@deepseek-ai/cordis';
import type { ClientRemote } from '@deepseek-ai/dsh-api-gateway/client';
import type { WorktreeConsoleAdapter } from '../../console-contract.js';
import { type GitWorktreeRemote } from '../../console-remote/remote.js';
export { createWorktreeConsoleRemoteAdapter } from './adapter.js';
/**
 * Activate on nearly the same prerequisites as the official Workspace Client.
 * The conversation-dependent Worktree surfaces run in a child fiber below so
 * the Workspace service can break the uiConversation -> uiWorkspace boot edge.
 *
 * The modern (0.2.x) official Browser additionally injects
 * `remote.directoryPicker`, whose provider entry waits for `uiWorkspace`
 * itself. Requiring it here would deadlock the web boot: this entry could not
 * provide `uiWorkspace` before the picker activates, and the picker would wait
 * for `uiWorkspace` forever. The picker is therefore resolved lazily at call
 * time through the managed context proxy (see officialContextProxy).
 */
export declare const inject: string[];
interface ConsoleClientContext extends Context {
    remote: ClientRemote & {
        gitWorktree: GitWorktreeRemote;
    };
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        worktreeConsole: WorktreeConsoleAdapter;
    }
}
/** Mount the package-owned strict Remote contribution in this Client fiber. */
export declare function apply(ctx: ConsoleClientContext): Promise<void>;
