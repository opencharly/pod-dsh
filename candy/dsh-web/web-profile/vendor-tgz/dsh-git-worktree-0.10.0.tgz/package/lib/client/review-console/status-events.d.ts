export declare const WORKTREE_REVIEW_REFRESH_EVENT = "dsh-git-worktree:review-refresh";
/** Notify all mounted review surfaces to re-read the Host-authoritative target. */
export declare function requestWorktreeReviewRefresh(sessionId: string): void;
