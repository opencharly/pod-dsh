import type { PreSessionDraftActions, PreSessionDraftState } from './controller.js';
/** Harness renamed the image-only composer API when adding general attachments. */
export type HarnessInputState = PreSessionDraftState | (Omit<PreSessionDraftState, 'imageIds'> & {
    readonly attachmentIds: readonly string[];
});
export type HarnessInputActions = PreSessionDraftActions | {
    setDraft(text: string): void;
    addAttachments(ids: readonly string[]): boolean;
    removeAttachment(id: string): void;
};
export declare function readHarnessInput(input: HarnessInputState): PreSessionDraftState;
/** Bind through the original receiver: target input faces may be class instances. */
export declare function adaptHarnessInputActions(input: HarnessInputActions): PreSessionDraftActions;
