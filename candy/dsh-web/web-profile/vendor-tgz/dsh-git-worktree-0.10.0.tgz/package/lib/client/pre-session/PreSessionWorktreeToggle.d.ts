import type { WorktreeConsoleAdapter, WorktreeConsoleTargetDetails } from '../../console-contract.js';
import type { PreSessionDraftActions, PreSessionDraftState, PreparePreSessionWorktreeRequest } from './controller.js';
export interface PreSessionWorktreeToggleProps {
    sessionId: string;
    session: {
        composerPhase: string;
    };
    input: PreSessionDraftState;
    inputActions: PreSessionDraftActions;
    adapter: WorktreeConsoleAdapter;
    controller: {
        prepare(request: PreparePreSessionWorktreeRequest): Promise<WorktreeConsoleTargetDetails>;
    };
}
/** Blank-session directory menu mounted in Harness's public composer tool row. */
export declare function PreSessionWorktreeToggle({ sessionId, session, input, inputActions, adapter, controller }: PreSessionWorktreeToggleProps): import("react").JSX.Element | null;
