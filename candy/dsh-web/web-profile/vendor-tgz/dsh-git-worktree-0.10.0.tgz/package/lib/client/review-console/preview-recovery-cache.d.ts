import type { WorktreeConsoleAdapter, WorktreeConsoleError, WorktreeConsolePreviewRecoveryPreflightRequest } from '../../console-contract.js';
import type { WorktreePreviewRecoveryPreflightView } from '../../types.js';
export type PreviewRecoverySnapshot = {
    status: 'idle';
} | {
    status: 'loading';
} | {
    status: 'success';
    preflight: WorktreePreviewRecoveryPreflightView;
} | {
    status: 'error';
    error: WorktreeConsoleError;
};
/** Identity-keyed, single-flight, read-only recovery assessment. Writes must force refresh. */
export declare function readPreviewRecoveryPreflight(adapter: WorktreeConsoleAdapter, identity: WorktreeConsolePreviewRecoveryPreflightRequest, force?: boolean): Promise<PreviewRecoverySnapshot>;
export declare function invalidatePreviewRecoveryPreflight(adapter: WorktreeConsoleAdapter, identity: WorktreeConsolePreviewRecoveryPreflightRequest): void;
export declare function usePreviewRecoveryPreflight(adapter: WorktreeConsoleAdapter | null | undefined, identity: WorktreeConsolePreviewRecoveryPreflightRequest | undefined, enabled: boolean): {
    snapshot: PreviewRecoverySnapshot;
    refresh(): Promise<PreviewRecoverySnapshot>;
};
