import type { WorktreeConsoleAdapter, WorktreeConsoleError, WorktreeConsolePreflightRequest } from '../../console-contract.js';
import type { WorktreeApplyPreflightView } from '../../types.js';
export type PreflightSnapshot = {
    status: 'idle';
} | {
    status: 'loading';
} | {
    status: 'success';
    preflight: WorktreeApplyPreflightView;
} | {
    status: 'error';
    error: WorktreeConsoleError;
};
/** Shared read-only request. `force` bypasses cached success and is mandatory before writes. */
export declare function readReviewPreflight(adapter: WorktreeConsoleAdapter, identity: WorktreeConsolePreflightRequest, force?: boolean): Promise<PreflightSnapshot>;
/** Discard one identity result; in-flight reads still publish only to the orphaned entry. */
export declare function invalidateReviewPreflight(adapter: WorktreeConsoleAdapter, identity: WorktreeConsolePreflightRequest): void;
export declare function useReviewPreflight(adapter: WorktreeConsoleAdapter | null | undefined, identity: WorktreeConsolePreflightRequest | undefined, enabled: boolean): {
    snapshot: PreflightSnapshot;
    refresh(): Promise<PreflightSnapshot>;
};
