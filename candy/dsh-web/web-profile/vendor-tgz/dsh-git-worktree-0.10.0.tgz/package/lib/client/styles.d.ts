export declare const WORKTREE_STYLES: string;
