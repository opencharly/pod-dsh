import type { WorktreeConsoleAdapter } from '../../console-contract.js';
import type { WorktreeClientServices } from '../actions.js';
export interface WorktreeManagerModalProps {
    open: boolean;
    sessionId: string;
    adapter: WorktreeConsoleAdapter;
    services: WorktreeClientServices;
    focusCheckoutId?: string | null;
    onClose(): void;
    onTargetChange?(): void;
}
/** Session-local entry point for the source-linked Worktree management surface. */
export declare function WorktreeManagerModal({ open, sessionId, adapter, services, focusCheckoutId, onClose, onTargetChange, }: WorktreeManagerModalProps): import("react").JSX.Element;
