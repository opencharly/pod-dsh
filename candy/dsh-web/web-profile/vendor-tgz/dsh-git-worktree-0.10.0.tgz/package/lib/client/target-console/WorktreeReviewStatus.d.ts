import type { WorktreeConsoleAdapter } from '../../console-contract.js';
import type { WorktreeClientServices } from '../actions.js';
export interface WorktreeReviewStatusProps {
    session: {
        sessionId: string;
    };
    adapter: WorktreeConsoleAdapter;
    services: WorktreeClientServices;
}
/** Domi-style compact delivery status above the native Harness composer. */
export declare function WorktreeReviewStatus({ session, adapter, services }: WorktreeReviewStatusProps): import("react").JSX.Element | null;
