import { type ComponentType } from 'react';
import type { Context } from '@deepseek-ai/cordis';
import type { WorkspaceBrowserProps } from '@deepseek-ai/dsh-client-ui-workspace/client';
import type { WorktreeConsoleAdapter, WorktreeSidebarTopologyResponse } from '../../console-contract.js';
/** Ephemeral presentation metadata consumed only by the gated official Browser derivative. */
export interface ManagedWorktreeSessionDecoration {
    kind: 'managed-worktree';
    state: WorktreeSidebarTopologyResponse['projects'][number]['tasks'][number]['state'];
    label: string;
    originalTitle: string;
}
interface ManagedWorkspaceGuard {
    ready: boolean;
    sessionIds: ReadonlySet<string>;
    workspaceIds: ReadonlySet<string>;
    blockSession(id: string): boolean;
    blockWorkspace(id: string): boolean;
}
interface OfficialWorkspaceBrowserProps extends WorkspaceBrowserProps {
    adapter: WorktreeConsoleAdapter;
    OfficialBrowser: ComponentType<WorkspaceBrowserProps>;
    guard?: ManagedWorkspaceGuard;
}
/**
 * Preserve the complete official Workspace Browser and change only its data
 * projection plus mutations that are unsafe for one-to-one Managed owners.
 */
export declare function ManagedOfficialWorkspaceBrowser({ adapter, OfficialBrowser, guard, ...officialProps }: OfficialWorkspaceBrowserProps): import("react").JSX.Element;
interface SidebarRegistrationContext {
    slots: {
        inject(name: string, callback: () => unknown): void;
        register(descriptor: Record<string, unknown>, component: ComponentType<any>): unknown;
    };
    [key: string]: unknown;
}
/**
 * Apply the version- and hash-gated official Workspace Client exactly once,
 * replacing only its Browser component while preserving its declaration tree,
 * locale, picker, stores, and directory-flow authorization.
 */
export declare function registerManagedWorkspaceSidebar(ctx: SidebarRegistrationContext, adapter: WorktreeConsoleAdapter, applyWorkspace?: (ctx: Context) => void): void;
export {};
