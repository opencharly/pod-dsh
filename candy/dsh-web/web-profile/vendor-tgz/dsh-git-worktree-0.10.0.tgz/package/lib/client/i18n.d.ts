import { type ReactNode } from 'react';
import { type Language, type Translator } from '../i18n/core.js';
import { clientMessages } from '../i18n/client-messages.js';
export type ClientTranslator = Translator<typeof clientMessages>;
export interface ClientLocaleSource {
    getSnapshot(): {
        active?: unknown;
    };
    subscribe(listener: () => void): () => void;
}
/** DSH LocaleFace resolves preference/browser fallback into snapshot.active. */
export declare function readClientLanguage(locale: unknown): Language;
export declare function clientTranslator(language?: Language): ClientTranslator;
export declare const defaultClientTranslator: ClientTranslator;
export declare function ClientI18nProvider({ locale, language, children }: {
    locale?: unknown;
    language?: Language;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useClientLanguage(): Language;
export declare function useClientTranslator(): ClientTranslator;
/** Imperative services resolve language at invocation time, not at module load. */
export declare function translatorForServices(services: {
    locale?: unknown;
}): ClientTranslator;
