export declare const REVIEW_CONSOLE_STYLES: string;
