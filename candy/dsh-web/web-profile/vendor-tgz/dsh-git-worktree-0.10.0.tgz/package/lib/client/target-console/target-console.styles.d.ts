export declare const TARGET_CONSOLE_STYLES: string;
