import type { WorktreeConsoleReviewSummary, WorktreeConsoleTargetSummary } from '../../console-contract.js';
export interface WorktreeReviewEvidence extends WorktreeConsoleReviewSummary {
    detailsMarkdown?: string;
}
export interface WorktreeReviewIdentity {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
}
export interface WorktreeReviewPanelProps {
    review: WorktreeReviewEvidence;
    identity?: WorktreeReviewIdentity;
    target?: WorktreeConsoleTargetSummary;
    unavailableMessage?: string;
}
export declare function reviewIsStale(target: WorktreeConsoleTargetSummary | undefined, identity: WorktreeReviewIdentity | undefined, review: WorktreeReviewEvidence): boolean;
export declare function WorktreeReviewPanel({ review, target, identity, unavailableMessage }: WorktreeReviewPanelProps): import("react").JSX.Element;
