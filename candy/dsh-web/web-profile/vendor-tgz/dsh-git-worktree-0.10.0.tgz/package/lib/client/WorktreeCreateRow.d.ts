import { type WorktreeClientServices } from './actions.js';
import { type ToolCallViewPropsLike } from './model.js';
interface Props extends ToolCallViewPropsLike {
    services: WorktreeClientServices;
}
export declare function WorktreeCreateRow({ block, services }: Props): import("react").JSX.Element;
export {};
