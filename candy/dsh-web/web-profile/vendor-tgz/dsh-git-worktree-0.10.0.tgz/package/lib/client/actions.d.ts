/** Browser-side orchestration over Harness Workspace and Session runtime faces. */
import type { WorktreeConsoleAdapter } from '../console-contract.js';
export interface IsolatedTargetLocation {
    managedRoot: string;
    targetSessionId: string;
}
export interface SnapshotStore<T> {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
}
export interface ClientSessionSnapshot {
    running: boolean;
    openState: 'cold' | 'loading' | 'open' | 'error';
    removed: boolean;
}
export interface ClientSessionBinding {
    /** Agent-scoped Client Context; present on real Harness bindings. */
    ctx?: unknown;
    session: {
        readonly sessionId?: string;
        getSnapshot?(): ClientSessionSnapshot;
        subscribe?(listener: () => void): () => void;
        prompt?(content: Array<{
            type: 'text';
            text: string;
        }>, mode: 'queue' | 'steer', signal?: AbortSignal): Promise<{
            ok: true;
            value: {
                accepted: true;
            };
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
                details?: Record<string, unknown>;
            };
        }>;
        command(line: string): Promise<{
            ok: true;
            value: {
                matched: boolean;
            };
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
    };
}
export interface ClientSessions {
    list: SnapshotStore<{
        current?: string;
        ids: string[];
        byId: Record<string, {
            cwd?: string;
            retainedBy?: object;
        } | undefined>;
    }>;
    /** Creates a catalogued Session identity; newer Hosts require retaining it before borrowing a binding. */
    create(input: {
        workspaceId: string;
        sessionId: string;
    }): Promise<string>;
    /** Newer Session Controller retains the target through initial open and the callback's handoff. */
    using?<T>(sessionId: string, options: {
        source: 'controllerOperation';
    }, operation: (reference: {
        binding: ClientSessionBinding;
    }) => T | Promise<T>): Promise<T>;
    /** Legacy Session Controller navigation (removed when UI Workspace owns selection). */
    open?(sessionId: string): void;
    binding(sessionId: string): ClientSessionBinding | undefined;
}
export interface ClientWorkspaces {
    create(input: {
        path: string;
    }): Promise<{
        workspaceId: string;
        path: string;
    }>;
    openPath(path: string): Promise<void>;
}
export interface WorktreeClientServices {
    /** UI Workspace owns navigation on Harness 0.1.6 and newer. */
    uiWorkspace?: {
        openSession(sessionId: string): void;
    };
    locale?: unknown;
    sessions: ClientSessions;
    workspaces: ClientWorkspaces;
    /** Optional public composer face used only by manual draft-prefill actions. */
    conversation?: {
        input: {
            for(ctx: unknown): PreSessionInput;
        };
    };
}
export type PreSessionInput = import('./pre-session/harness-input.js').HarnessInputActions;
/** Additional public Harness faces used only by the blank-session preparation flow. */
export interface PreSessionWorktreeServices extends WorktreeClientServices {
    sessions: ClientSessions;
    workspaces: ClientWorkspaces & {
        archiveSession(sessionId: string): Promise<void>;
        delete(workspaceId: string): Promise<void>;
    };
    conversation: {
        input: {
            for(ctx: unknown): PreSessionInput;
        };
        blocks: {
            set(sessionId: string, block: {
                reason: string;
            } | undefined): void;
            storeFor(sessionId: string): {
                getSnapshot(): {
                    reason: string;
                } | undefined;
            };
        };
    };
}
/** Prefer the UI owner of navigation; refuse to silently lose a target selection. */
export declare function navigateToSession(services: Pick<WorktreeClientServices, 'sessions' | 'uiWorkspace' | 'locale'>, sessionId: string): void;
/** Resolve the sole visible main Session across the legacy selection and new retainedBy contract. */
export declare function selectedSessionId(snapshot: ReturnType<ClientSessions['list']['getSnapshot']>): string | undefined;
/** Open a Session only when the Harness list proves both its identity and cwd. */
export declare function openExistingSession(services: Pick<WorktreeClientServices, 'sessions' | 'locale' | 'uiWorkspace'>, sessionId: string, expectedCwd: string): boolean;
/** Idempotently register the managed root, create the preallocated Session, and navigate. */
export declare function openIsolatedTarget(services: WorktreeClientServices, payload: IsolatedTargetLocation, isActive?: () => boolean): Promise<void>;
/**
 * Inspect a path-free Host authorization, verify exact checkout/owner identity,
 * then reuse the cwd-validated Session navigation path.
 */
export declare function openAuthorizedWorktreeTarget(adapter: Pick<WorktreeConsoleAdapter, 'inspect'>, services: WorktreeClientServices, callerSessionId: string, expected: {
    checkoutId: string;
    ownerSessionId: string;
}, isActive?: () => boolean): Promise<void>;
/** Prefill a visible recovery request. This never invokes command/send/followup. */
export declare function prefillSessionDraft(services: WorktreeClientServices, sessionId: string, text: string): boolean;
/** Submit an exact review-card acceptance as an explicit user command. */
export declare function finalizeCurrentSession(services: Pick<WorktreeClientServices, 'sessions' | 'locale'>, reviewId: string, revision: number, retention: 'cleanup' | 'retain_24h' | 'retain_3d' | 'retain_manual'): Promise<void>;
