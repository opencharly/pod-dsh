import { type ClientTranslator } from './i18n.js';
/** Pure replay-stable ToolView models derived only from logged call/result slices. */
export interface ToolContentBlock {
    type: string;
    text?: string;
    [key: string]: unknown;
}
export interface ToolCallBlockLike {
    callId: string;
    argsRaw?: string;
    call?: {
        argsRaw?: string;
    };
    content?: ToolContentBlock[];
    kind?: string;
    isError?: boolean;
    error?: {
        name?: string;
        code?: string;
    };
}
export interface ToolCallViewPropsLike {
    callId: string;
    /** Supplied by Harness for every session-scoped ToolView. */
    sessionId?: string;
    toolName: string;
    block: ToolCallBlockLike;
    cwd?: string;
    openFile?: (path: string) => void;
    inspect?: () => void;
}
export interface WorktreeCreatePayload {
    kind: 'worktree_target_created';
    checkoutId: string;
    targetSessionId: string;
    managedRoot: string;
    phase: string;
    currentOid: string;
    sourceSessionId: string;
}
export interface WorktreeReviewPayload {
    kind: 'worktree_ready_for_review';
    state: 'ready_for_review';
    reviewId: string;
    revision: number;
    iteration: number;
    changedFiles: string[];
}
export interface ReviewArgs {
    summary: string;
    details?: string;
    validationStatus: 'passed' | 'failed' | 'partial' | 'not_run';
    validationSummary?: string;
    tests: Array<{
        command: string;
        status: 'passed' | 'failed' | 'not_run';
        summary?: string;
    }>;
    suggestedCommitMessage: string;
}
export type ToolLifecycle = 'running' | 'ok' | 'error' | 'stopped';
export interface ParsedTool<TPayload, TArgs = Record<string, never>> {
    lifecycle: ToolLifecycle;
    payload: TPayload | null;
    args: TArgs | null;
    error: string | null;
}
export declare function parseCreateTool(block: ToolCallBlockLike, t?: ClientTranslator): ParsedTool<WorktreeCreatePayload>;
export declare function parseReviewTool(block: ToolCallBlockLike, t?: ClientTranslator): ParsedTool<WorktreeReviewPayload, ReviewArgs>;
