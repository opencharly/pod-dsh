import { type ClientTranslator } from '../i18n.js';
import type { WorktreeConsoleAdapter } from '../../console-contract.js';
import { type WorktreeClientServices } from '../actions.js';
export interface WorktreeApplyConflictRecoveryRequest {
    kind: 'worktree_apply_conflict';
    sessionId: string;
    requestId: string;
    checkoutId: string;
    /** Review that the user's explicit recovery action invalidated. */
    reviewId: string;
    /** Authoritative Working revision returned by resumeRevision. */
    revision: number;
    localHeadOid: string;
    conflictingFiles: string[];
}
export interface WorktreeReviewRegenerationRequest {
    kind: 'worktree_review_regeneration';
    sessionId: string;
    requestId: string;
    checkoutId: string;
    reviewId: string;
    /** Ready revision that must remain unchanged because this path is read-only. */
    revision: number;
}
export type WorktreeRecoveryRequest = WorktreeApplyConflictRecoveryRequest | WorktreeReviewRegenerationRequest;
export type WorktreeRecoveryStatus = 'queued' | 'sending' | 'sent' | 'failed' | 'cancelled';
export interface WorktreeRecoverySnapshot {
    status: WorktreeRecoveryStatus;
    request: WorktreeRecoveryRequest;
    error?: string;
}
export declare function buildWorktreeRecoveryPrompt(request: WorktreeRecoveryRequest, t?: ClientTranslator): string;
/** Durable context queue only; browser state is untrusted and every send revalidates Host + Harness identity. */
export declare function enqueueWorktreeRecovery(input: {
    adapter: WorktreeConsoleAdapter;
    services: WorktreeClientServices;
    request: WorktreeRecoveryRequest;
    isActive: () => boolean;
}): WorktreeRecoverySnapshot;
export declare function restoreWorktreeRecovery(input: {
    sessionId: string;
    adapter: WorktreeConsoleAdapter;
    services: WorktreeClientServices;
    isActive?: () => boolean;
}): WorktreeRecoverySnapshot | null;
export declare function retryWorktreeRecovery(sessionId: string): void;
export declare function getWorktreeRecoverySnapshot(sessionId: string): WorktreeRecoverySnapshot | null;
export declare function subscribeWorktreeRecovery(sessionId: string, listener: () => void): () => void;
export declare function useWorktreeRecoverySnapshot(sessionId: string | undefined): WorktreeRecoverySnapshot | null;
/** Drop renderer-lifetime evidence after a new review supersedes it or in deterministic tests. */
export declare function cancelWorktreeRecovery(sessionId: string, requestId?: string): void;
/** Simulate renderer/module teardown while retaining durable unsent context. */
export declare function detachWorktreeRecoveryRuntime(sessionId: string): void;
export declare function clearWorktreeRecovery(sessionId: string): void;
