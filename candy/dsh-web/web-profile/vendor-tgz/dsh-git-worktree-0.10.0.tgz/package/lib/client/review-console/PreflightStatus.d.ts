import type { WorktreeConsoleTargetSummary } from '../../console-contract.js';
import type { WorktreeApplyPreflightView } from '../../types.js';
import type { PreflightSnapshot } from './preflight-cache.js';
export declare function PreflightStatus({ snapshot, target, compact, onRefresh, onRecovery, onOpenHolder, busy, }: {
    snapshot: PreflightSnapshot;
    target?: WorktreeConsoleTargetSummary;
    compact?: boolean;
    onRefresh(): void;
    onRecovery(preflight: WorktreeApplyPreflightView): void;
    onOpenHolder(): void;
    busy: boolean;
}): import("react").JSX.Element | null;
