import type { WorktreeConsoleAdapter } from '../../console-contract.js';
import { type WorktreeClientServices } from '../actions.js';
export interface TargetStatusActionProps {
    sessionId: string;
    adapter: WorktreeConsoleAdapter;
    services: WorktreeClientServices;
}
/** Interactive Session Target capsule with source-linked management actions. */
export declare function TargetStatusAction({ sessionId, adapter, services }: TargetStatusActionProps): import("react").JSX.Element;
