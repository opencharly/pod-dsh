import type { WorktreeConsoleTargetSummary } from '../../console-contract.js';
import type { WorktreeReviewEvidence, WorktreeReviewIdentity } from './WorktreeReviewPanel.js';
export { WorktreeReviewPanel } from './WorktreeReviewPanel.js';
export type { WorktreeReviewEvidence, WorktreeReviewIdentity, WorktreeReviewPanelProps, } from './WorktreeReviewPanel.js';
/** Project one persisted review into the shared compact card/dock evidence shape. */
export declare function reviewEvidenceFromTarget(target: WorktreeConsoleTargetSummary, detailsMarkdown?: string): WorktreeReviewEvidence | null;
/** Build the exact CAS identity required by Finalize and advanced review reads. */
export declare function reviewIdentityFromTarget(sessionId: string, target: WorktreeConsoleTargetSummary): WorktreeReviewIdentity | null;
