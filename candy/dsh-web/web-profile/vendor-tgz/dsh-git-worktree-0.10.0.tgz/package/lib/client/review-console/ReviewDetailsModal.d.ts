import type { WorktreeConsoleTargetSummary } from '../../console-contract.js';
import type { WorktreeApplyPreflightView } from '../../types.js';
import { type ClientTranslator } from '../i18n.js';
import { type ReviewIconName } from './ReviewIcon.js';
export declare function validationText(status: string, t: ClientTranslator): string;
export declare function validationIcon(status: string): ReviewIconName;
export declare function ReviewDetailsModal({ open, onClose, target, preflight }: {
    open: boolean;
    onClose(): void;
    target: WorktreeConsoleTargetSummary;
    preflight?: WorktreeApplyPreflightView;
}): import("react").JSX.Element | null;
