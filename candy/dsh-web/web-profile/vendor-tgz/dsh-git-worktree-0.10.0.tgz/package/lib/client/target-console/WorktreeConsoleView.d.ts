import { type WorktreeConsoleAdapter } from '../../console-contract.js';
import { type WorktreeClientServices } from '../actions.js';
export interface WorktreeConsoleViewProps {
    embedded?: boolean;
    sessionId: string;
    adapter: WorktreeConsoleAdapter;
    services: WorktreeClientServices;
    focusCheckoutId?: string | null;
    onTargetChange?(): void;
}
/** Source-linked Worktree management surface backed only by WorktreeConsoleAdapter. */
export declare function WorktreeConsoleView({ embedded, sessionId, adapter, services, focusCheckoutId, onTargetChange, }: WorktreeConsoleViewProps): import("react").JSX.Element;
