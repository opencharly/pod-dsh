import type { WorktreeConsoleAdapter, WorktreeConsoleTargetDetails } from '../../console-contract.js';
import { type PreSessionWorktreeServices } from '../actions.js';
export interface PreSessionDraftState {
    readonly draft: string;
    readonly imageIds: readonly string[];
    readonly occurrences: readonly unknown[];
    readonly phase: string;
    /** Monotonic Harness input revision captured when the confirmation opened. */
    readonly draftRev?: number;
}
export interface PreSessionDraftActions {
    setDraft(text: string): void;
    addImages(ids: readonly string[]): boolean;
    removeImage(id: string): void;
}
export interface PreparePreSessionWorktreeRequest {
    sessionId: string;
    /** Immutable confirmation-time snapshot moved into the target. */
    input: PreSessionDraftState;
    /** Live source state used for the final compare-and-clear boundary. */
    currentInput?: () => PreSessionDraftState;
    inputActions: PreSessionDraftActions;
    initialCommitConfirmationToken?: string;
    /** Invalidated when the composer leaves its source Session. */
    isCurrentSession?: () => boolean;
}
export declare class PreSessionWorktreeError extends Error {
    readonly recoveryRequired: boolean;
    constructor(message: string, recoveryRequired?: boolean);
}
/**
 * Prepares an isolated blank Session before the normal Harness composer sends.
 * The controller never sends a prompt; after it opens the target, the resident
 * composer remains the sole submission path.
 */
export declare class PreSessionWorktreeController {
    private readonly adapter;
    private readonly services;
    private readonly inflight;
    constructor(adapter: WorktreeConsoleAdapter, services: PreSessionWorktreeServices);
    prepare(request: PreparePreSessionWorktreeRequest): Promise<WorktreeConsoleTargetDetails>;
    private run;
    private rollback;
}
export declare function createPreSessionWorktreeController(adapter: WorktreeConsoleAdapter, services: PreSessionWorktreeServices): PreSessionWorktreeController;
