import type { ComponentType } from 'react';
import type { SessionSnapshot } from '@deepseek-ai/dsh-api-session-controller/client';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-store';
import type { WorktreeConsoleAdapter } from '../../console-contract.js';
import type { PreSessionWorktreeServices } from '../actions.js';
import { type HarnessInputActions, type HarnessInputState } from './harness-input.js';
/** rc.1 input.left has no owner snapshot props; snapshots come from standard hooks. */
export interface PreSessionSlotProps {
    sessionId: string;
    useSession: SnapshotSelectorHook<SessionSnapshot>;
    useConversation: SnapshotSelectorHook<{
        readonly activeTargets: ReadonlySet<string>;
    }>;
    useInput: SnapshotSelectorHook<HarnessInputState>;
    inputActions: HarnessInputActions;
}
export interface PreSessionSlotContextLike {
    slots: {
        inject(name: 'conversation.input.left', callback: () => unknown): void;
        register(descriptor: Record<string, unknown>, component: ComponentType<PreSessionSlotProps>): unknown;
    };
}
/** Register the blank-session switch in Harness's public composer tool row. */
export declare function registerPreSessionWorktree(ctx: PreSessionSlotContextLike, adapter: WorktreeConsoleAdapter, services: PreSessionWorktreeServices): void;
export { PreSessionWorktreeController, PreSessionWorktreeError, createPreSessionWorktreeController } from './controller.js';
export { PreSessionWorktreeToggle } from './PreSessionWorktreeToggle.js';
