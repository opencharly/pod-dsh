import type { ReactNode } from 'react';
import type { WorktreeConsoleAdapter, WorktreeConsoleError, WorktreeConsoleTargetSummary } from '../../console-contract.js';
import { type WorktreeClientServices } from '../actions.js';
import type { WorktreeReviewEvidence, WorktreeReviewIdentity } from './WorktreeReviewPanel.js';
interface ReviewActionsProps {
    review: WorktreeReviewEvidence;
    adapter?: WorktreeConsoleAdapter | null;
    services?: WorktreeClientServices;
    identity?: WorktreeReviewIdentity;
    target?: WorktreeConsoleTargetSummary;
    disabled: boolean;
    unavailableMessage: string;
    renderStatus?: (operation: Mutation | null) => ReactNode;
    focusReview?: () => void;
    isActive?: () => boolean;
    onStale: (error: WorktreeConsoleError) => void;
    onTargetChange: (target: WorktreeConsoleTargetSummary) => void;
}
type Mutation = 'preview' | 'checkpoint' | 'resume_revision' | 'recovery' | 'recovery_analysis' | 'recovery_handoff' | 'open_holder' | 'rollback' | 'finish' | 'finalize_preview' | 'discard' | 'retry_cleanup';
export declare function ReviewActions({ review, adapter, services, identity, target, disabled, unavailableMessage, focusReview, renderStatus, isActive, onStale, onTargetChange, }: ReviewActionsProps): import("react").JSX.Element;
export {};
