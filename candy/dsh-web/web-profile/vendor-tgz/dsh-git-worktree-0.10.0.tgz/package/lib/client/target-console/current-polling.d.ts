import type { WorktreeConsoleAdapter, WorktreeConsoleCurrentResponse, WorktreeConsoleOutcome } from '../../console-contract.js';
import type { Language } from '../../i18n/core.js';
type Result = {
    outcome: WorktreeConsoleOutcome<WorktreeConsoleCurrentResponse>;
} | {
    error: unknown;
};
type Listener = (result: Result) => void;
/** Adapter identity isolates Client instances; language isolates translated results. */
export declare function subscribeCurrent(adapter: WorktreeConsoleAdapter, sessionId: string, language: Language, listener: Listener): () => void;
export {};
