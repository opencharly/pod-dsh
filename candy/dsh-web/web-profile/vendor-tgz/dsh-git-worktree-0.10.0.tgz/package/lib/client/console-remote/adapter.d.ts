import { type Language } from '../../i18n/core.js';
import type { WorktreeConsoleAdapter } from '../../console-contract.js';
import type { GitWorktreeRemote } from '../../console-remote/remote.js';
export declare function createWorktreeConsoleRemoteAdapter(remote: GitWorktreeRemote, getLanguage?: () => Language): WorktreeConsoleAdapter;
