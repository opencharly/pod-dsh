import type { WorktreeConsoleTargetSummary } from '../../console-contract.js';
export declare function DeliveryProof({ target, compact }: {
    target: WorktreeConsoleTargetSummary;
    compact?: boolean;
}): import("react").JSX.Element | null;
