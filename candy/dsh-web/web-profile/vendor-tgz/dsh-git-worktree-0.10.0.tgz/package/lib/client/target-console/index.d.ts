import { type ComponentType } from 'react';
import type { WorktreeConsoleAdapter } from '../../console-contract.js';
import type { WorktreeClientServices } from '../actions.js';
export interface TargetConsoleContextLike {
    slots: {
        inject(name: 'conversation.session.header.actions' | 'conversation.input.dock', callback: () => unknown): void;
        register(descriptor: Record<string, unknown>, component: ComponentType<any>): unknown;
    };
}
/** Register the Harness-native Session Target contributions against an injected adapter seam. */
export declare function registerTargetConsole(ctx: TargetConsoleContextLike, adapter: WorktreeConsoleAdapter, services: WorktreeClientServices): void;
export { TargetStatusAction } from './TargetStatusAction.js';
export { WorktreeConsoleView } from './WorktreeConsoleView.js';
export { WorktreeManagerModal } from './WorktreeManagerModal.js';
export { WorktreeReviewStatus } from './WorktreeReviewStatus.js';
