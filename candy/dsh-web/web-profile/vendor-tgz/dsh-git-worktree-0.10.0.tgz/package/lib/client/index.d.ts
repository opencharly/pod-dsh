/** Browser entry: dedicated ToolViews for Worktree target handoff and review. */
import { type ComponentType } from 'react';
import type { WorktreeConsoleAdapter } from '../console-contract.js';
export { registerTargetConsole } from './target-console/index.js';
export declare const WORKTREE_CONSOLE_ADAPTER_SERVICE = "worktreeConsole";
interface ClientContextLike {
    get(name: string): unknown;
    effect(setup: () => void | (() => void), label?: string): void;
    slots: {
        inject(name: 'tool.call.toolview' | 'conversation.session.header.actions' | 'conversation.input.dock' | 'conversation.input.left', callback: () => unknown): void;
        register(descriptor: Record<string, unknown>, component: ComponentType<any>): unknown;
    };
}
/** Required client services. */
export declare const inject: string[];
/** Register replay-stable keyed rows and one scoped stylesheet. */
export declare function apply(ctx: ClientContextLike, adapterOverride?: WorktreeConsoleAdapter): void;
