/** Convert a canonical repository basename into one safe, readable path segment. */
export declare function sanitizeManagedWorktreeLabel(rawName: string | undefined): string;
/** Stable fallback partition that distinguishes repositories sharing one basename. */
export declare function createManagedWorktreeRepositoryKey(canonicalGitRoot: string): string;
/** Physical basename: repository identity + trusted checkout identity only. */
export declare function createManagedWorktreeDirectoryName(input: {
    repositoryName: string;
    checkoutId: string;
    identityLength?: number;
}): string;
export interface ManagedWorktreePathCandidates {
    siblingContainer: string;
    siblingRoot: string;
    fallbackContainer: string;
    fallbackRoot: string;
}
/**
 * Generate one collision-length candidate without touching the filesystem.
 * The caller probes 8/12/full checkout identities and chooses the first path
 * that does not already exist.
 */
export declare function createManagedWorktreePathCandidates(input: {
    localGitRoot: string;
    managedCheckoutsRoot: string;
    repositoryKey: string;
    checkoutId: string;
    identityLength?: number;
}): ManagedWorktreePathCandidates;
