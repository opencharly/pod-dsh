import type { InvocationDescriptor, TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
export declare const WORKTREE_CONSOLE_DESCRIPTORS: readonly InvocationDescriptor[];
export declare const WORKTREE_CONSOLE_REMOTE: TypertRemoteContribution;
