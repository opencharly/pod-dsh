import { z } from 'zod';
import { type WorktreeConsoleCreatePreviewRecoveryHandoffResponse, type WorktreeConsoleCreateResponse, type WorktreeConsoleCurrentResponse, type WorktreeConsoleInspectResponse, type WorktreeConsoleListResponse, type WorktreeConsoleMutationResponse, type WorktreeConsoleOutcome, type WorktreeConsolePreflightResponse, type WorktreeConsolePreviewRecoveryPreflightResponse, type WorktreeConsoleReviewDiffResponse, type WorktreeSidebarTopologyResponse } from '../console-contract.js';
export declare const sessionIdSchema: z.ZodString;
export declare const checkoutIdSchema: z.ZodString;
export declare const reviewIdSchema: z.ZodString;
export declare const commitMessageSchema: z.ZodString;
export declare const revisionSchema: z.ZodNumber;
export declare const oidSchema: z.ZodUnion<readonly [z.ZodLiteral<"unversioned">, z.ZodLiteral<"unborn">, z.ZodString]>;
export declare const previewIdSchema: z.ZodString;
export declare const generationSchema: z.ZodString;
export declare const requestIdSchema: z.ZodString;
export declare const booleanSchema: z.ZodBoolean;
export declare const optionalLanguageSchema: z.ZodOptional<z.ZodEnum<{
    zh: "zh";
    en: "en";
}>>;
export declare const optionalBooleanSchema: z.ZodUnion<readonly [z.ZodBoolean, z.ZodUndefined]>;
export declare const retentionSchema: z.ZodEnum<{
    cleanup: "cleanup";
    retain_24h: "retain_24h";
    retain_3d: "retain_3d";
    retain_manual: "retain_manual";
}>;
export declare const retainedModeSchema: z.ZodEnum<{
    retain_24h: "retain_24h";
    retain_3d: "retain_3d";
    retain_manual: "retain_manual";
}>;
export declare const recoveryContinuationSchema: z.ZodObject<{
    kind: z.ZodLiteral<"worktree_apply_conflict">;
    requestId: z.ZodString;
    checkoutId: z.ZodString;
    reviewId: z.ZodString;
    revision: z.ZodNumber;
    localHeadOid: z.ZodUnion<readonly [z.ZodLiteral<"unversioned">, z.ZodLiteral<"unborn">, z.ZodString]>;
    conflictingFiles: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const reviewRegenerationProofSchema: z.ZodObject<{
    kind: z.ZodLiteral<"worktree_review_regeneration">;
    requestId: z.ZodString;
    checkoutId: z.ZodString;
    reviewId: z.ZodString;
    revision: z.ZodNumber;
}, z.core.$strict>;
export declare const previewRecoveryAnalysisProofSchema: z.ZodObject<{
    kind: z.ZodLiteral<"worktree_preview_recovery_analysis">;
    requestId: z.ZodString;
    checkoutId: z.ZodString;
    reviewId: z.ZodString;
    previewId: z.ZodString;
    revision: z.ZodNumber;
    generation: z.ZodString;
}, z.core.$strict>;
export declare const previewRecoveryHandoffProofSchema: z.ZodObject<{
    kind: z.ZodLiteral<"worktree_preview_recovery_handoff">;
    requestId: z.ZodString;
    checkoutId: z.ZodString;
    sourceCheckoutId: z.ZodString;
    reviewId: z.ZodString;
    previewId: z.ZodString;
    revision: z.ZodNumber;
    generation: z.ZodString;
}, z.core.$strict>;
export declare const previewRecoveryHandoffResponseSchema: z.ZodType<WorktreeConsoleCreatePreviewRecoveryHandoffResponse>;
export declare function outcomeSchema<T>(value: z.ZodType<T>): z.ZodType<WorktreeConsoleOutcome<T>>;
export declare const currentResponseSchema: z.ZodType<WorktreeConsoleCurrentResponse>;
export declare const createPreflightResponseSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"ready">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"files">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"empty">;
    confirmationToken: z.ZodString;
}, z.core.$strict>], "kind">;
export declare const createResponseSchema: z.ZodType<WorktreeConsoleCreateResponse>;
export declare const inspectResponseSchema: z.ZodType<WorktreeConsoleInspectResponse>;
export declare const listResponseSchema: z.ZodType<WorktreeConsoleListResponse>;
export declare const sidebarTopologyResponseSchema: z.ZodType<WorktreeSidebarTopologyResponse>;
export declare const mutationResponseSchema: z.ZodType<WorktreeConsoleMutationResponse>;
export declare const preflightResponseSchema: z.ZodType<WorktreeConsolePreflightResponse>;
export declare const previewRecoveryProofSchema: z.ZodObject<{
    sessionId: z.ZodString;
    checkoutId: z.ZodString;
    reviewId: z.ZodString;
    previewId: z.ZodString;
    revision: z.ZodNumber;
    generation: z.ZodString;
    receiptFingerprint: z.ZodString;
    localFingerprint: z.ZodString;
    localHeadOid: z.ZodString;
    localHeadRef: z.ZodNullable<z.ZodString>;
    localHeadTreeOid: z.ZodString;
    localIndexTreeOid: z.ZodString;
    localWorkingTreeOid: z.ZodString;
    rollback: z.ZodUnion<readonly [z.ZodObject<{
        status: z.ZodLiteral<"safe">;
        targetTreeOid: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"blocked">;
        code: z.ZodEnum<{
            stale_local: "stale_local";
            preview_modified: "preview_modified";
            project_acceptance_busy: "project_acceptance_busy";
            commit_isolation_conflict: "commit_isolation_conflict";
            operation_not_allowed: "operation_not_allowed";
        }>;
        message: z.ZodString;
        conflictingFiles: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>]>;
    finalize: z.ZodUnion<readonly [z.ZodObject<{
        status: z.ZodLiteral<"safe">;
        taskTreeOid: z.ZodString;
        finalIndexTreeOid: z.ZodString;
        expectedWorkingTreeOid: z.ZodString;
        commitRequired: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"blocked">;
        code: z.ZodEnum<{
            stale_local: "stale_local";
            preview_modified: "preview_modified";
            project_acceptance_busy: "project_acceptance_busy";
            commit_isolation_conflict: "commit_isolation_conflict";
            operation_not_allowed: "operation_not_allowed";
        }>;
        message: z.ZodString;
        conflictingFiles: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>]>;
    blocker: z.ZodOptional<z.ZodObject<{
        checkoutId: z.ZodString;
        ownerSessionId: z.ZodString;
        revision: z.ZodNumber;
        state: z.ZodEnum<{
            finalized: "finalized";
            retained: "retained";
            working: "working";
            ready_for_review: "ready_for_review";
            preview_active: "preview_active";
            preview_detached: "preview_detached";
            delivered: "delivered";
        }>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const previewRecoveryPreflightResponseSchema: z.ZodType<WorktreeConsolePreviewRecoveryPreflightResponse>;
export declare const reviewDiffResponseSchema: z.ZodType<WorktreeConsoleReviewDiffResponse>;
