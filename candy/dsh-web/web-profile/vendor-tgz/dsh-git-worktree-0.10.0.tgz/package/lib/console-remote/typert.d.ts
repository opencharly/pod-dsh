import type { TypertContribution } from '@deepseek-ai/dsh-typert-registry/types';
/** Manual strict Host contribution discovered by the official Typert Loader through `./typert`. */
export declare const TYPERT: TypertContribution;
