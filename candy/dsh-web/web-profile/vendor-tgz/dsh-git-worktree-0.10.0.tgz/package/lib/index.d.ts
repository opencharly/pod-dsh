/**
 * dsh-git-worktree plugin entry. The session-checkout domain (state machine,
 * apply engine, ports) is Domi-ported and host-agnostic; this file is the DSH
 * plugin face: exports the domain error type and module contract, builds the
 * DSH adapters, mounts the state machine, and registers safe model tools,
 * human `/worktree` acceptance commands, and Session Target runtime context.
 * @module dsh-git-worktree
 */
import type { Context } from '@deepseek-ai/cordis';
import type { GitCheckoutSnapshot, ManagedApplyConflictRecoveryContinuation, ManagedPreviewRecoveryAnalysisContinuation, ManagedPreviewRecoveryHandoffContinuation, ManagedReviewRegenerationContinuation } from './ports.js';
import type { ManagedWorktreeSummaryView, BulkCleanupManagedWorktreeCandidate, BulkCleanupManagedWorktreesResult, SessionCheckoutErrorCode, SessionCheckoutOperation, SessionCheckoutOperationResult, SessionTargetBindChoice, SessionTargetView, WorktreeRetentionMode, WorktreeValidationItem, WorktreeValidationStatus, WorktreeApplyPreflightView, WorktreePreviewRecoveryPreflightView, WorktreePreviewRecoveryProof } from './types.js';
/** Stable domain failure raised by the session-checkout state machine and its adapters. */
export declare class SessionCheckoutError extends Error {
    readonly code: SessionCheckoutErrorCode;
    /**
     * @param code - stable error code from `SESSION_CHECKOUT_ERROR_CODES`.
     * @param message - user-facing message, surfaced verbatim by tools.
     */
    constructor(code: SessionCheckoutErrorCode, message: string);
}
export interface SessionCheckoutReconcileSummary {
    recoveryRequiredCheckoutIds: string[];
    orphanedCheckoutIds: string[];
    dirtyOrphanedCheckoutIds: string[];
    retainedCheckoutCount: number;
}
export interface ManageManagedWorktreeInput {
    checkoutId: string;
    expectedRevision: number;
    action: 'cleanup_retained' | 'retry_cleanup' | 'set_retention' | 'discard';
    retention?: Exclude<WorktreeRetentionMode, 'cleanup'>;
    confirmDirty?: boolean;
    rollbackPreview?: boolean;
}
export interface ListManagedWorktreesInput {
    projectId?: string;
    needsAttention?: boolean;
    checkoutId?: string;
    includeDiagnostics?: boolean;
}
export interface MarkReadyForReviewInput {
    detailsMarkdown?: string;
    summary: string;
    validationStatus: WorktreeValidationStatus;
    validationSummary?: string;
    tests: WorktreeValidationItem[];
    suggestedCommitMessage: string;
}
/** Handoff data used by the client to create the authoritative isolated Workspace/Session. */
export interface IsolatedTargetLaunch {
    targetSessionId: string;
    managedRoot: string;
    target: SessionTargetView;
}
/** Complete core interface the session-checkout module exposes to business callers. */
export interface SessionCheckoutModule {
    inspect(sessionId: string): Promise<SessionTargetView>;
    /** Synchronous registry snapshot for replay-stable model runtime context. */
    runtimeContext(sessionId: string): string;
    /** Read-only sync preflight; modifies no Local, worktree, registry, review state, or Git refs. */
    preflight?(sessionId: string, expectedRevision: number): Promise<WorktreeApplyPreflightView>;
    /** Strictly read-only detached Preview recovery assessment and deterministic revalidation context. */
    preflightPreviewRecovery?(sessionId: string, expectedRevision: number, expectedReviewId: string, expectedPreviewId: string): Promise<WorktreePreviewRecoveryPreflightView>;
    /** Cross-module mutation under the same exclusive lock as bind/apply/discard/cleanup. */
    runExclusiveSessionMutation<T>(sessionId: string, operation: (target: SessionTargetView) => Promise<T>): Promise<T>;
    bind(sessionId: string, choice: SessionTargetBindChoice): Promise<SessionTargetView>;
    /** Reserve a distinct owner session and checkout without changing the source session cwd/identity. */
    createIsolatedTarget(sourceSessionId: string, targetSessionId: string): Promise<IsolatedTargetLaunch>;
    /** Recreate a cleaned delivered owner's immutable cwd as the next isolated iteration. */
    beginNextIteration(sessionId: string, expectedRevision: number): Promise<SessionTargetView>;
    /** Invalidate an unsynced review and resume the same iteration without touching Local. */
    resumeRevision(sessionId: string, expectedRevision: number, expectedReviewId: string, recovery?: Omit<ManagedApplyConflictRecoveryContinuation, 'workingRevision'>): Promise<SessionTargetView>;
    /** Persist a Host-authoritative one-shot Read Only review-regeneration request. */
    prepareReviewRegeneration(sessionId: string, expectedRevision: number, expectedReviewId: string, requestId: string): Promise<ManagedReviewRegenerationContinuation>;
    /** Persist an exact detached Recovery proof before the Client prompts the owner Agent for read-only analysis. */
    preparePreviewRecoveryAnalysis(sessionId: string, proof: WorktreePreviewRecoveryProof, requestId: string): Promise<ManagedPreviewRecoveryAnalysisContinuation>;
    /** Create a fresh managed Worktree at latest Local HEAD while preserving all old detached evidence. */
    createPreviewRecoveryHandoff(sessionId: string, proof: WorktreePreviewRecoveryProof, targetSessionId: string, requestId: string): Promise<IsolatedTargetLaunch & {
        continuation: ManagedPreviewRecoveryHandoffContinuation;
    }>;
    markReadyForReview(sessionId: string, input: MarkReadyForReviewInput): Promise<SessionTargetView>;
    operate(input: SessionCheckoutOperation): Promise<SessionCheckoutOperationResult>;
    listManagedWorktrees(input?: ListManagedWorktreesInput): Promise<ManagedWorktreeSummaryView[]>;
    /** Caller-scoped list for model and human session surfaces. */
    listManagedWorktreesForSession(sessionId: string, input?: Omit<ListManagedWorktreesInput, 'projectId'>): Promise<ManagedWorktreeSummaryView[]>;
    /** Caller-scoped management; never treats persisted owner ids as authorization. */
    manageManagedWorktreeForSession(sessionId: string, input: ManageManagedWorktreeInput): Promise<ManagedWorktreeSummaryView>;
    /** Main-owned read-only cleanup inspection; writes no registry, refs, or directories. */
    inspectManagedWorktreeCleanup(input?: ListManagedWorktreesInput): Promise<ManagedWorktreeSummaryView[]>;
    bulkCleanupManagedWorktrees(candidates: BulkCleanupManagedWorktreeCandidate[]): Promise<BulkCleanupManagedWorktreesResult>;
    manageManagedWorktree(input: ManageManagedWorktreeInput): Promise<ManagedWorktreeSummaryView>;
    /** Resolve a managed checkout's canonical root after identity validation (workspace registration). */
    resolveManagedRoot(checkoutId: string): Promise<string>;
    /** Fresh validated observation; callers can project it without re-reading Git. */
    observeManagedCheckout?(checkoutId: string): Promise<{
        managedRoot: string;
        snapshot: GitCheckoutSnapshot;
        dirty: boolean;
    }>;
    cleanupExpiredRetained(now?: number): Promise<string[]>;
    reconcile(): Promise<SessionCheckoutReconcileSummary>;
}
import z from '@deepseek-ai/schemastery';
import { type GitTimeoutOptions } from './adapters/git-options.js';
export * from './console-contract.js';
export declare const inject: {
    tools: {};
    commands: {};
    subprocess: {};
    loader: {
        await: boolean;
    };
};
export declare const Config: z<Schemastery.ObjectS<{
    /**
     * Plugin state directory (registry, disabled-hooks root). Defaults to
     * `$DSH_HOME/plugins/dsh-git-worktree` (`~/.dsh` when `DSH_HOME` is unset).
     * The property is optional by construction (schemastery object properties
     * are optional inputs).
     */
    stateDir: z<string, string>;
    gitTimeoutMs: z<number, number>;
    worktreeAddTimeoutMs: z<number, number>;
}>, Schemastery.ObjectT<{
    /**
     * Plugin state directory (registry, disabled-hooks root). Defaults to
     * `$DSH_HOME/plugins/dsh-git-worktree` (`~/.dsh` when `DSH_HOME` is unset).
     * The property is optional by construction (schemastery object properties
     * are optional inputs).
     */
    stateDir: z<string, string>;
    gitTimeoutMs: z<number, number>;
    worktreeAddTimeoutMs: z<number, number>;
}>>;
/**
 * Mount the plugin: DSH adapters, the session-checkout module, safe worktree
 * tools, human acceptance command, dynamic target context, startup recovery,
 * the retention-expiry timer, and — last, without ever blocking activation —
 * the Workspace provider election. Every Remote, tool, and command surface
 * above must be live before that election so a wedged Loader reconciliation
 * cannot starve the Client boot chain.
 */
export declare function apply(ctx: Context, config?: {
    stateDir?: string;
} & GitTimeoutOptions): Promise<void>;
