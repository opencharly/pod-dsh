import { type ProjectSkillStore } from './adapters/project-skills.js';
import type { ApplyBaseStrategy } from './types.js';
export interface ApplyPlanInput {
    baseOid: string;
    isolatedPath: string;
    localPath: string;
}
export interface ApplyPlan {
    revision: string;
    localFingerprint: string;
    isolatedFingerprint: string;
    effectiveBaseOid: string;
    baseStrategy: ApplyBaseStrategy;
    localHeadOid: string;
    /** null 表示 Local 当前为 detached HEAD；Apply 允许，Finish 会拒绝自动提交。 */
    localHeadRef: string | null;
    isolatedHeadOid: string;
    changedFiles: string[];
}
export interface ReviewSnapshotResult {
    status: 'ready';
    isolatedFingerprint: string;
    isolatedHeadOid: string;
    changedFiles: string[];
}
export type InspectReviewResult = ReviewSnapshotResult | ApplyPlanErrorResult;
export interface ApplyReadyPlanResult {
    status: 'ready';
    plan: ApplyPlan;
}
export interface ApplyConflictPlanResult {
    status: 'conflict';
    revision: string;
    localFingerprint: string;
    isolatedFingerprint: string;
    effectiveBaseOid: string;
    baseStrategy: ApplyBaseStrategy;
    /** 冲突计算时的真实 Local HEAD，供 Isolated Agent 在当前 Worktree 内同步并解决冲突。 */
    localHeadOid: string;
    isolatedHeadOid: string;
    conflictingFiles: string[];
}
export interface ApplyPlanErrorResult {
    status: 'error';
    error: ApplyError;
}
export type ApplyPlanResult = ApplyReadyPlanResult | ApplyConflictPlanResult | ApplyPlanErrorResult;
export interface ApplySuccessResult {
    status: 'applied';
    changedFiles: string[];
    /** 本次已整合的 Isolated 快照 commit；不创建 ref，仅供后续 Apply 作为内部基线。 */
    nextBaseOid: string;
}
export interface ApplyErrorResult {
    status: 'error';
    error: ApplyError;
}
export type ApplyResult = ApplySuccessResult | ApplyErrorResult;
export interface FinishSuccessResult {
    status: 'finished';
    changedFiles: string[];
    /** null 表示 Worktree 与 Local 已一致，没有创建空提交。 */
    commitOid: string | null;
    /** 本次已整合的 Isolated 快照，供清理未完成时后续 Apply 去重。 */
    nextBaseOid: string;
}
export type FinishResult = FinishSuccessResult | ApplyErrorResult;
export interface PreviewReceipt {
    previewId: string;
    reviewId: string;
    iteration: number;
    previewedAt: number;
    configuredBaseOid: string;
    effectiveBaseOid: string;
    baseStrategy: ApplyBaseStrategy;
    localHeadOid: string;
    localHeadRef: string | null;
    localFingerprintBefore: string;
    localFingerprintPreview: string;
    localWorkingTreeOid: string;
    localIndexTreeOid: string;
    previewWorkingTreeOid: string;
    isolatedHeadOid: string;
    isolatedFingerprint: string;
    isolatedSnapshotOid: string;
    changedFiles: string[];
}
export interface PreviewSuccessResult {
    status: 'previewed';
    receipt: PreviewReceipt;
    changedFiles: string[];
}
export type PreviewResult = PreviewSuccessResult | ApplyErrorResult;
export interface RollbackSuccessResult {
    status: 'preview_rolled_back';
    changedFiles: string[];
}
export type RollbackResult = RollbackSuccessResult | ApplyErrorResult;
export interface CheckpointInput {
    isolatedPath: string;
    expectedFingerprint: string;
    expectedHeadOid: string;
    commitMessage: string;
    /** Persist the prepared commit and Host journal before detached HEAD/index mutation. */
    beforeCommit?(prepared: {
        commitOid: string;
        parentOid: string;
        indexTreeOid: string;
        changedFiles: string[];
    }): Promise<void>;
}
export interface CheckpointSuccessResult {
    status: 'checkpointed';
    commitOid: string;
    parentOid: string;
    changedFiles: string[];
    isolatedFingerprint: string;
}
export type CheckpointResult = CheckpointSuccessResult | ApplyErrorResult;
export interface CheckpointRecoverySuccessResult {
    status: 'checkpoint_recovered' | 'checkpoint_aborted';
    isolatedFingerprint: string;
}
export type CheckpointRecoveryResult = CheckpointRecoverySuccessResult | ApplyErrorResult;
export type PreviewRecoveryActionBlockCode = 'stale_local' | 'preview_modified' | 'commit_isolation_conflict' | 'operation_not_allowed';
export interface PreviewRecoveryBlockedAction {
    status: 'blocked';
    code: PreviewRecoveryActionBlockCode;
    message: string;
    conflictingFiles?: string[];
}
export interface PreviewRecoverySafeRollback {
    status: 'safe';
    targetTreeOid: string;
}
export interface PreviewRecoverySafeFinalize {
    status: 'safe';
    taskTreeOid: string;
    finalIndexTreeOid: string;
    expectedWorkingTreeOid: string;
    commitRequired: boolean;
}
export interface PreviewRecoveryAssessment {
    localFingerprint: string;
    localHeadOid: string;
    localHeadRef: string | null;
    localHeadTreeOid: string;
    localIndexTreeOid: string;
    localWorkingTreeOid: string;
    rollback: PreviewRecoverySafeRollback | PreviewRecoveryBlockedAction;
    finalize: PreviewRecoverySafeFinalize | PreviewRecoveryBlockedAction;
}
export interface InvalidInputApplyError {
    code: 'invalid_input';
    message: string;
}
export interface InvalidPlanApplyError {
    code: 'invalid_plan';
    message: string;
}
export interface StaleLocalApplyError {
    code: 'stale_local';
    message: string;
}
export interface StaleIsolatedApplyError {
    code: 'stale_isolated';
    message: string;
}
export interface GitApplyError {
    code: 'git_error';
    message: string;
    /** Host may clear only a planning journal when the engine proved Local was restored exactly. */
    recoveryState?: 'unchanged' | 'uncertain';
}
export interface CommitIsolationApplyError {
    code: 'commit_isolation_conflict';
    message: string;
}
export interface OperationNotAllowedApplyError {
    code: 'operation_not_allowed';
    message: string;
}
export interface PreviewModifiedApplyError {
    code: 'preview_modified';
    message: string;
}
export type ApplyError = InvalidInputApplyError | InvalidPlanApplyError | StaleLocalApplyError | StaleIsolatedApplyError | GitApplyError | CommitIsolationApplyError | OperationNotAllowedApplyError | PreviewModifiedApplyError;
export interface SessionCheckoutApplyEngine {
    inspectReview(input: ApplyPlanInput): Promise<InspectReviewResult>;
    checkpoint(input: CheckpointInput): Promise<CheckpointResult>;
    recoverCheckpoint(input: {
        isolatedPath: string;
        commitOid: string;
        parentOid: string;
        expectedIndexTreeOid: string;
    }): Promise<CheckpointRecoveryResult>;
    /** 复用真实 Apply merge 计算，但不持久化可执行 plan，也不修改任一 checkout。 */
    preflight(input: ApplyPlanInput): Promise<ApplyPlanResult>;
    plan(input: ApplyPlanInput): Promise<ApplyPlanResult>;
    apply(plan: ApplyPlan): Promise<ApplyResult>;
    finish(plan: ApplyPlan, options: {
        commitMessage: string;
    }): Promise<FinishResult>;
    preview(plan: ApplyPlan, options: {
        previewId: string;
        reviewId: string;
        iteration: number;
        /** Local 写入前持久化 receipt artifacts/journal；失败时不得触碰 Local。 */
        beforeWrite?(receipt: PreviewReceipt): Promise<void>;
    }): Promise<PreviewResult>;
    /** Strictly read-only detached Preview recovery assessment; it persists no executable plan. */
    assessPreviewRecovery(input: {
        localPath: string;
        receipt: PreviewReceipt;
    }): Promise<PreviewRecoveryAssessment | ApplyErrorResult>;
    rollback(input: {
        localPath: string;
        receipt: PreviewReceipt;
        /** Persists the mutation journal before the final Local CAS; no Local write may happen before it resolves. */
        beforeWrite?(): Promise<void>;
    }): Promise<RollbackResult>;
    finalize(input: {
        localPath: string;
        receipt: PreviewReceipt;
        commitMessage: string;
        /** Commit object 已创建但 branch ref 尚未更新时持久化恢复信息。 */
        beforeCommit?(commitOid: string): Promise<void>;
    }): Promise<FinishResult>;
}
export interface SessionCheckoutApplyEngineOptions {
    projectSkills?: ProjectSkillStore;
    /** 测试/宿主 seam：在最后一次 Local fingerprint 校验前执行。 */
    beforeFinalLocalValidation?(): Promise<void> | void;
    /** 测试/宿主 seam：在 Local 写入完成、独立写后验证开始前执行。 */
    afterLocalWriteBeforeVerification?(): Promise<void> | void;
    /** Test seam immediately before the authoritative managed-Worktree checkpoint CAS. */
    beforeFinalIsolatedValidation?(): Promise<void> | void;
    /** Test seam after checkpoint HEAD/index writes and before independent verification. */
    afterIsolatedWriteBeforeVerification?(): Promise<void> | void;
}
export declare function createSessionCheckoutApplyEngine(options?: SessionCheckoutApplyEngineOptions): SessionCheckoutApplyEngine;
