import type { ManagedCheckoutsRegistry, SessionCheckoutRegistryPort } from '../ports.js';
/** Atomic JSON registry file with `.tmp`/`.bak` crash recovery (see safe-file). */
export declare class AtomicJsonCheckoutRegistry implements SessionCheckoutRegistryPort {
    private readonly path;
    constructor(path: string);
    read(): ManagedCheckoutsRegistry;
    write(registry: ManagedCheckoutsRegistry): void;
}
