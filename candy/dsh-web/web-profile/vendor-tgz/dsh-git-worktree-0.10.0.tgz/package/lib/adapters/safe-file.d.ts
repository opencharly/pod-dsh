/**
 * 原子写入 JSON 文件：write-to-temp → rename
 * 写入前自动保留 .bak 备份
 */
export declare function writeJsonFileAtomic(filePath: string, data: object, skipBackup?: boolean): void;
/** 原子重写文本文件（用于 JSONL 会话等非单个 JSON 文档）。 */
export declare function writeTextFileAtomic(filePath: string, content: string): void;
/**
 * 安全读取 JSON 索引文件
 * 优先读主文件，损坏则尝试 .tmp / .bak，都失败返回 null
 */
export declare function readJsonFileSafe<T>(filePath: string): T | null;
