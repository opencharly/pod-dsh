import type { Context } from '@deepseek-ai/cordis';
import type { SkillCandidate, SkillDefinition, SkillLookupOptions, SkillProvider, SkillProviderControl, SkillProviderObservation } from '@deepseek-ai/dsh-skill';
import type { SessionCheckoutRegistryPort } from '../ports.js';
/** Resolve against host-owned records, never a root claimed by a Skill file. */
export declare function managedSkillRoot(registry: SessionCheckoutRegistryPort): (cwd: string) => Promise<string | null>;
/** Additional project source only; native .dsh/.agents discovery remains unchanged. */
export declare class ClaudeProjectSkillProvider implements SkillProvider {
    private readonly ctx;
    private readonly control;
    private readonly resolveRoot;
    readonly name = "worktree-project-claude";
    private readonly providers;
    private operations;
    private disposed;
    private run;
    constructor(ctx: Context, control: SkillProviderControl, resolveRoot: (cwd: string) => Promise<string | null>);
    private provider;
    list(options: SkillLookupOptions): Promise<SkillCandidate[] | SkillProviderObservation>;
    private listNow;
    get(candidate: SkillCandidate, options: SkillLookupOptions): Promise<SkillDefinition | undefined>;
    private getNow;
    observeHostMutation(path: string): void;
    dispose(): Promise<void>;
}
export declare function mountProjectSkillProvider(ctx: Context, registry: SessionCheckoutRegistryPort): void;
