export interface SkillRead {
    path: string;
    maxBytes: number;
}
export interface SkillBytes {
    path: string;
    content: Buffer;
    mode: number;
}
export declare function readSkillFiles(root: string, identity: string, files: readonly SkillRead[]): Promise<SkillBytes[]>;
export declare function createSkillDirectories(root: string, identity: string, directories: readonly string[]): Promise<void>;
export declare function createSkillFiles(root: string, identity: string, files: readonly SkillBytes[]): Promise<void>;
