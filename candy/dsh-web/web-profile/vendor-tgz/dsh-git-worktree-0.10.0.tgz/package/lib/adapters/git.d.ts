import { ProjectSkillStore } from './project-skills.js';
import { type GitTimeoutOptions } from './git-options.js';
import type { Context } from '@deepseek-ai/cordis';
import type { SessionCheckoutGitPort } from '../ports.js';
export interface GitPortOptions extends GitTimeoutOptions {
    /** Directory holding the empty `core.hooksPath` target; created by the caller. */
    hooksPath: string;
    projectSkills?: ProjectSkillStore;
}
/** Build the `ctx.subprocess`-backed git port. */
export declare function createDshGitPort(ctx: Context, options: GitPortOptions): SessionCheckoutGitPort;
