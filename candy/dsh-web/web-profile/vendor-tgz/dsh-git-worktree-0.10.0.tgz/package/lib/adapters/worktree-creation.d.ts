import type { WorktreeCreationEvidence } from '../ports.js';
type Result = {
    code: number;
    stdout: string;
    stderr: string;
    quiescent?: boolean;
};
type Run = (cwd: string, args: string[], creating?: boolean) => Promise<Result>;
/** Registration is short; the expensive checkout runs only after its ownership proof is durable. */
export declare function createWorktree(localRoot: string, target: string, baseOid: string, run: Run, saveEvidence?: (evidence: WorktreeCreationEvidence) => void): Promise<void>;
export {};
