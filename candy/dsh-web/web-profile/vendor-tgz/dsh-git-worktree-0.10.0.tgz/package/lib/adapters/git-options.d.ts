export interface GitTimeoutOptions {
    gitTimeoutMs?: number;
    worktreeAddTimeoutMs?: number;
}
export declare const DEFAULT_GIT_TIMEOUT_MS = 120000;
export declare const DEFAULT_WORKTREE_ADD_TIMEOUT_MS: number;
export declare const MAX_GIT_TIMEOUT_MS: number;
export declare function validateGitTimeouts(options: GitTimeoutOptions): void;
export declare function gitTimeoutMs(args: readonly string[], options: GitTimeoutOptions): number;
