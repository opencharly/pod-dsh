/**
 * DSH lookup adapter: maps sessions and projects onto the harness's
 * `workspaceRegistry` service (retrieved dynamically, like the ecosystem's
 * plugins, because the published package version lags the rc.6 runtime). A
 * session's project is found by scanning workspace session accounts; when a
 * cleaned immutable cwd makes Harness filter a still-live Session from that
 * projection, the immutable live header may restore the exact mapping. A
 * project record maps to a workspace's `id`/`title`/`path`. Missing service or
 * records degrade to `undefined`, which the state machine treats as
 * recovery/orphan facts rather than failures.
 * @module dsh-git-worktree/adapters/lookup
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionCheckoutLookupPort } from '../ports.js';
/** Minimal structural view of the harness workspace registry (see `@deepseek-ai/dsh-workspace`). */
export interface WorkspaceLike {
    readonly id: string;
    readonly path: string;
    readonly title: string;
    readonly sessionIds: readonly string[];
}
export interface WorkspaceRegistryLike {
    list(): WorkspaceLike[];
    get(id: string): WorkspaceLike | undefined;
    resolveByPath(path: string): Promise<WorkspaceLike | undefined>;
    create(path: string, title?: string): Promise<WorkspaceLike>;
    delete(id: string): Promise<boolean>;
}
/** Build the lookup port over Harness workspace and live-session projections. */
export declare function createDshLookupPort(ctx: Context): SessionCheckoutLookupPort;
