import type { GitCheckoutSnapshot, InitialCommitPreflight } from '../ports.js';
export interface GitCommitProtocol {
    prepare: string;
    beforeCommit(): Promise<void>;
}
type Run = (root: string, args: string[], input?: string | GitCommitProtocol) => Promise<{
    code: number;
    stdout: string;
    stderr: string;
}>;
/** Only the Console's confirmed host action calls initialize; normal Git inspection is read-only. */
export declare function initialCommitActions(inspect: (root: string) => Promise<GitCheckoutSnapshot | null>, run: Run): {
    preflightInitialCommit: (root: string) => Promise<InitialCommitPreflight>;
    initializeEmptyRepository: (root: string, fingerprint: string, assertAuthorized?: () => Promise<void>) => Promise<string>;
};
export {};
