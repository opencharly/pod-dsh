export declare const PROJECT_SKILL_ROOTS: readonly [".dsh/skills", ".agents/skills", ".claude/skills"];
interface Entry {
    path: string;
    hash: string;
    mode: number;
}
export interface SkillSnapshot {
    directories?: string[];
    files: Array<Entry & {
        content: Buffer;
    }>;
}
export interface CarriedSkillState {
    paths: string[];
    fingerprint: string;
    modified: boolean;
}
export declare function assertSkillTree(root: string, skillRoot: typeof PROJECT_SKILL_ROOTS[number]): Promise<void>;
/** Host-private provenance: never accept an exclusion list from the managed checkout. */
export declare class ProjectSkillStore {
    private readonly directory;
    constructor(directory: string);
    private file;
    snapshot(source: string): Promise<SkillSnapshot>;
    private load;
    carry(snapshot: SkillSnapshot, target: string): Promise<void>;
    scope(root: string): Promise<{
        paths: string[];
        directories: string[];
    } | null>;
    paths(root: string): Promise<string[] | null>;
    state(root: string, tracked?: ReadonlySet<string>): Promise<CarriedSkillState | null>;
    assertRemovable(root: string, tracked: ReadonlySet<string>): Promise<void>;
    forget(root: string): Promise<void>;
}
export declare function trackedSkillPaths(indexEntries: Buffer | string, headPaths?: Buffer | string): Set<string>;
/** Only ?? records are auxiliary; tracked edits, renames and deletions stay visible. */
export declare function hasDeliverableStatus(output: string, auxiliary: ReadonlySet<string>, directories?: readonly string[]): boolean;
export declare function assertSkillPath(root: string, path: string): Promise<void>;
export {};
