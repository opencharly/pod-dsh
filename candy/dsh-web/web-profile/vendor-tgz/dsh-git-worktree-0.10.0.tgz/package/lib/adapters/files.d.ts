import type { SessionCheckoutFilesPort } from '../ports.js';
/** Build the node-fs-backed files port. */
export declare function createNodeFilesPort(): SessionCheckoutFilesPort;
