import type { Context } from '@deepseek-ai/cordis';
import { type WorkspaceClientFlavor } from './host-compat.js';
export declare const WORKSPACE_PROVIDER_CONDITION = "!!get('worktreeWorkspaceProvider') && [...loader.entries()].some(entry => entry.options?.name === 'dsh-git-worktree' && !entry.disabled)";
declare module '@deepseek-ai/cordis' {
    interface Context {
        worktreeWorkspaceProvider: boolean;
    }
}
/** Tuning seams for {@link mountWorkspaceProviderLifecycle} (tests). */
export interface WorkspaceProviderLifecycleOptions {
    /** Ceiling for a single Loader disable/restore operation in milliseconds. */
    operationTimeoutMs?: number;
}
/**
 * Reconcile the conditional patch with the public Loader lifecycle. A disabled
 * expression is evaluated dynamically, but the Web module registry caches rows
 * by plugin name; a change to the replacement alone does not re-elect Workspace.
 * Restarting the official entry through Loader operations publishes real module
 * events without saving any disabled flag or changing the user's profile.
 *
 * Election never blocks (or fails) plugin activation: Host boots start entries
 * concurrently, so the official entry's disable may race a fiber that is still
 * starting, and Loader versions differ in how such a dispose settles. Each
 * operation therefore races a ceiling; a wedged one is reported once and the
 * entry stays guarded until the real operation settles, while the next Loader
 * event retries the election. The disabled expression itself already keeps any
 * not-yet-started official entry out of the Web module graph, so the Web side
 * never observes two `uiWorkspace` providers from a slow reconciliation.
 */
export declare function mountWorkspaceProviderLifecycle(ctx: Context, flavor?: WorkspaceClientFlavor, options?: WorkspaceProviderLifecycleOptions): void;
