import type { SessionCheckoutModule } from './index.js';
import type { SessionCheckoutDependencies } from './ports.js';
export declare function createSessionCheckoutModule(dependencies: SessionCheckoutDependencies): SessionCheckoutModule;
