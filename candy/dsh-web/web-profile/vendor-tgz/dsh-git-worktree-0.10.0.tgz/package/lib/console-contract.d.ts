/**
 * JSON-only shared contract for the future Harness-native Worktree Console.
 *
 * This module deliberately contains no Cordis, React, Remote or filesystem
 * implementation. Host and Client tracks share these DTOs while preserving one
 * authority rule: every Host operation resolves an exact caller Session and
 * re-validates project, owner, cwd, revision and review identity at execution.
 * @module dsh-git-worktree/console-contract
 */
import { type SessionCheckoutErrorCode, type SessionCheckoutPhase, type WorktreeRetentionMode, type WorktreeApplyPreflightView, type WorktreePreviewRecoveryPreflightView, type WorktreePreviewRecoveryProof, type WorktreeAcceptanceBlockerView, type WorktreeDeliveryProofView, type WorktreeValidationItem, type WorktreeValidationStatus, type WorktreeCheckpointView } from './types.js';
export declare const WORKTREE_CONSOLE_TARGET_STATES: readonly ["local", "creating", "working", "ready_for_review", "preview_active", "preview_detached", "retained", "cleanup_pending", "recovery_required", "delivered"];
export type WorktreeConsoleTargetState = typeof WORKTREE_CONSOLE_TARGET_STATES[number];
export type WorktreeConsoleDeliveryState = 'working' | 'ready_for_review' | 'preview_active' | 'preview_detached' | 'finalized' | 'retained' | 'delivered';
/** Minimal domain facts required to project a stable, UI-facing state. */
export interface WorktreeConsoleProjectionSource {
    kind: 'local' | 'isolated';
    phase: SessionCheckoutPhase;
    deliveryState?: WorktreeConsoleDeliveryState;
}
/** Recovery and mutation phases take precedence over a stale delivery label. */
export declare function consoleStateFromDomain(source: WorktreeConsoleProjectionSource): WorktreeConsoleTargetState;
export interface WorktreeConsoleProject {
    id: string;
    name: string;
}
export interface WorktreeConsoleCapabilities {
    create: boolean;
    open: boolean;
    inspect: boolean;
    discard: boolean;
    preflight: boolean;
    preview: boolean;
    /** Save the exact reviewed snapshot as a managed-Worktree-only stage and continue editing. */
    checkpoint: boolean;
    /** Invalidate an unsynced review and resume the same iteration without touching Local. */
    resumeRevision: boolean;
    rollbackPreview: boolean;
    /** Direct Ready → Commit path that skips Local Preview. */
    finalize: boolean;
    finalizePreview: boolean;
    setRetention: boolean;
    retryCleanup: boolean;
    /** Recreate a cleaned delivered owner's immutable cwd for iteration + 1. */
    beginNextIteration: boolean;
}
export interface WorktreeConsolePreviewRecovery {
    previewId: string;
    detachedAt: number;
    reason: 'stale_local' | 'preview_modified';
    attemptedAction: 'rollback_preview' | 'finalize_preview' | 'discard';
}
export type WorktreeConsoleDeliveryProof = WorktreeDeliveryProofView;
export interface WorktreeConsoleReviewSummary {
    reviewId: string;
    revision: number;
    iteration: number;
    preparedAt: number;
    summary: string;
    validationStatus: WorktreeValidationStatus;
    validationSummary?: string;
    tests: WorktreeValidationItem[];
    changedFiles: string[];
    suggestedCommitMessage: string;
}
/** Path-free row safe for project lists and header status chips. */
export interface WorktreeConsoleTargetSummary {
    project: WorktreeConsoleProject;
    checkoutId: string | null;
    sourceSessionId: string;
    ownerSessionId: string;
    targetSessionId: string | null;
    iteration: number;
    revision: number;
    state: WorktreeConsoleTargetState;
    phase: SessionCheckoutPhase | 'local';
    dirty: boolean;
    currentOid: string;
    commitOid: string | null;
    retention?: Exclude<WorktreeRetentionMode, 'cleanup'>;
    retainedAt?: number;
    expiresAt?: number | null;
    cleanupMessage?: string;
    deliveryProof?: WorktreeConsoleDeliveryProof;
    review?: WorktreeConsoleReviewSummary;
    checkpoints?: WorktreeCheckpointView[];
    checkpointGeneration?: string;
    reviewSlot?: 'available' | 'waiting';
    reviewSlotOwnerSessionId?: string;
    reviewSlotHolder?: WorktreeAcceptanceBlockerView;
    previewRecovery?: WorktreeConsolePreviewRecovery;
    capabilities: WorktreeConsoleCapabilities;
}
/** Identity-validated detail used only when the caller may open this target. */
export interface WorktreeConsoleTargetDetails extends WorktreeConsoleTargetSummary {
    managedRoot: string | null;
    /** Host-validated canonical Local root used only for source Session navigation. */
    sourceRoot: string | null;
    sourceOid: string;
    currentBranch: string | null;
    /** Owner-only Host proof for one explicitly authorized recovery continuation. */
    recoveryContinuation?: WorktreeRecoveryProof;
}
export interface WorktreeConsoleCurrentRequest {
    sessionId: string;
}
export interface WorktreeConsoleCurrentResponse {
    target: WorktreeConsoleTargetDetails;
}
export interface WorktreeConsoleListRequest {
    sessionId: string;
    needsAttention?: boolean;
    includeDelivered?: boolean;
}
export interface WorktreeConsoleListResponse {
    project: WorktreeConsoleProject;
    worktrees: WorktreeConsoleTargetSummary[];
}
export type WorktreeSidebarTaskState = 'working' | 'ready_for_review' | 'preview_active' | 'preview_detached' | 'recovery_required' | 'finalized' | 'discarded';
/** Path-free, read-only task identity used only to aggregate the Workspace sidebar. */
export interface WorktreeSidebarTask {
    checkoutId: string;
    ownerSessionId: string;
    sourceSessionId: string;
    iteration: number;
    revision: number;
    phase: SessionCheckoutPhase;
    state: WorktreeSidebarTaskState;
}
export interface WorktreeSidebarProject {
    project: WorktreeConsoleProject;
    tasks: WorktreeSidebarTask[];
    /** Host-proven directory membership, including cleaned and older iterations. No paths or mutation authority. */
    memberships?: {
        workspaceIds: string[];
        sessionIds: string[];
    };
}
export interface WorktreeSidebarTopologyResponse {
    projects: WorktreeSidebarProject[];
    /** Server-pinned Host package generation; unknown generations must not mount a guessed Client Browser. */
    workspaceClientFlavor?: 'legacy' | 'alpha' | 'next' | 'modern' | 'unsupported';
}
/** targetSessionId is allocated on the Host; the browser never chooses ownership identity. */
export type WorktreeConsoleCreatePreflightResponse = {
    kind: 'ready';
} | {
    kind: 'empty';
    confirmationToken: string;
} | {
    kind: 'files';
};
export interface WorktreeConsoleCreateRequest {
    sourceSessionId: string;
}
export interface WorktreeConsoleCreateResponse {
    target: WorktreeConsoleTargetDetails;
    targetSessionId: string;
    managedRoot: string;
}
export interface WorktreeConsoleInspectRequest {
    sessionId: string;
    checkoutId: string;
}
export interface WorktreeConsoleInspectResponse {
    target: WorktreeConsoleTargetDetails;
}
export interface WorktreeConsoleDiscardRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    confirmDirty: boolean;
    rollbackPreview?: boolean;
}
export interface WorktreeConsolePreflightRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
}
export interface WorktreeConsolePreflightResponse {
    preflight: WorktreeApplyPreflightView;
}
export interface WorktreeConsolePreviewRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
}
export interface WorktreeConsoleCheckpointRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
    expectedGeneration: string;
    requestId: string;
    commitMessage: string;
}
export interface WorktreeConsoleResumeRevisionRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
    /** Present only for the explicit conflict-recovery action; Host re-runs conflict preflight under CAS. */
    conflictContinuation?: WorktreeApplyConflictContinuation;
}
export interface WorktreeConsolePreviewRecoveryPreflightRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
    expectedPreviewId: string;
}
export interface WorktreeConsolePreviewRecoveryPreflightResponse {
    preflight: WorktreePreviewRecoveryPreflightView;
}
export interface WorktreeConsolePreparePreviewRecoveryAnalysisRequest extends WorktreeConsolePreviewRecoveryPreflightRequest {
    recoveryProof: WorktreePreviewRecoveryProof;
}
export interface WorktreeConsoleCreatePreviewRecoveryHandoffRequest extends WorktreeConsolePreviewRecoveryPreflightRequest {
    recoveryProof: WorktreePreviewRecoveryProof;
}
export interface WorktreeConsoleCreatePreviewRecoveryHandoffResponse extends WorktreeConsoleCreateResponse {
    recoveryContinuation: WorktreePreviewRecoveryHandoffProof;
}
export interface WorktreeConsoleRollbackPreviewRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    resumeRevision?: boolean;
    recoveryProof?: WorktreePreviewRecoveryProof;
}
export interface WorktreeConsoleFinalizeRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
    /** Explicit user-confirmed message; Host revalidates the bounded value. */
    commitMessage: string;
    retention: WorktreeRetentionMode;
}
export interface WorktreeConsoleFinalizePreviewRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
    commitMessage: string;
    retention: WorktreeRetentionMode;
    recoveryProof?: WorktreePreviewRecoveryProof;
}
export interface WorktreeConsoleSetRetentionRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    retention: Exclude<WorktreeRetentionMode, 'cleanup'>;
}
export interface WorktreeConsoleRetryCleanupRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
}
export interface WorktreeConsoleBeginNextIterationRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
}
export interface WorktreeConsoleMutationResponse {
    target: WorktreeConsoleTargetSummary;
    changedFiles?: string[];
    commitOid?: string | null;
    checkpoint?: WorktreeCheckpointView;
    recoveryContinuation?: WorktreeRecoveryProof;
}
export interface WorktreeConsolePrepareRegenerationRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
}
export type WorktreeConsoleFileStatus = 'added' | 'modified' | 'deleted' | 'renamed' | 'binary';
export interface WorktreeConsoleDiffFile {
    path: string;
    previousPath?: string;
    status: WorktreeConsoleFileStatus;
    patch: string | null;
    truncated: boolean;
}
/** Review reads are bound to the same immutable identity required by Finalize. */
export interface WorktreeConsoleReviewDiffRequest {
    sessionId: string;
    checkoutId: string;
    expectedRevision: number;
    expectedReviewId: string;
}
export interface WorktreeConsoleReviewDiffResponse {
    reviewId: string;
    revision: number;
    files: WorktreeConsoleDiffFile[];
    truncated: boolean;
}
export declare const WORKTREE_CONSOLE_ERROR_CODES: readonly ["session_not_found", "project_not_found", "project_root_missing", "not_git_repository", "target_unselected", "target_already_bound", "project_mismatch", "checkout_missing", "checkout_mismatch", "recovery_required", "registry_corrupt", "git_operation_failed", "not_owner", "stale_target", "dirty_confirmation_required", "apply_conflict", "apply_failed", "invalid_input", "invalid_plan", "stale_local", "stale_isolated", "git_error", "commit_isolation_conflict", "checkout_limit_reached", "project_acceptance_busy", "operation_not_allowed", "preview_not_active", "preview_modified", "recovery_unsafe", "transport_unavailable", "malformed_response"];
export type WorktreeConsoleErrorCode = SessionCheckoutErrorCode | 'transport_unavailable' | 'malformed_response';
export type WorktreeConsoleErrorCategory = 'permission' | 'stale' | 'confirmation' | 'recovery' | 'conflict' | 'unavailable' | 'invalid' | 'internal';
export type WorktreeConsoleRecovery = 'none' | 'refresh' | 'confirm_dirty' | 'open_recovery' | 'retry';
export interface WorktreeApplyConflictContinuation {
    kind: 'worktree_apply_conflict';
    /** Stable identity for Client single-flight and retry within this renderer lifetime. */
    requestId: string;
    checkoutId: string;
    /** Review that remains Ready until the user explicitly resumes it for conflict resolution. */
    reviewId: string;
    /** Authoritative revision after the failed real-time write attempt returned to Ready. */
    revision: number;
    localHeadOid: string;
    conflictingFiles: string[];
}
export interface WorktreeApplyConflictRecoveryProof {
    kind: 'worktree_apply_conflict';
    requestId: string;
    checkoutId: string;
    reviewId: string;
    /** Exact Working revision produced by the Host conflict-resume CAS. */
    revision: number;
    localHeadOid: string;
    conflictingFiles: string[];
}
export interface WorktreeReviewRegenerationProof {
    kind: 'worktree_review_regeneration';
    requestId: string;
    checkoutId: string;
    reviewId: string;
    revision: number;
}
export interface WorktreePreviewRecoveryAnalysisProof {
    kind: 'worktree_preview_recovery_analysis';
    requestId: string;
    checkoutId: string;
    reviewId: string;
    previewId: string;
    revision: number;
    generation: string;
}
export interface WorktreePreviewRecoveryHandoffProof {
    kind: 'worktree_preview_recovery_handoff';
    requestId: string;
    checkoutId: string;
    sourceCheckoutId: string;
    reviewId: string;
    previewId: string;
    revision: number;
    generation: string;
}
export type WorktreeRecoveryProof = WorktreeApplyConflictRecoveryProof | WorktreeReviewRegenerationProof | WorktreePreviewRecoveryAnalysisProof | WorktreePreviewRecoveryHandoffProof;
export type WorktreeConsoleContinuation = WorktreeApplyConflictContinuation;
export interface WorktreeConsoleError {
    code: WorktreeConsoleErrorCode;
    message: string;
    details?: Record<string, string | number | boolean | null>;
    continuation?: WorktreeConsoleContinuation;
}
export type WorktreeConsoleOutcome<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: WorktreeConsoleError;
};
export interface WorktreeConsoleErrorMeta {
    category: WorktreeConsoleErrorCategory;
    recovery: WorktreeConsoleRecovery;
    retryable: boolean;
}
export declare function worktreeConsoleErrorMeta(code: WorktreeConsoleErrorCode): WorktreeConsoleErrorMeta;
/** Normalized Client seam; Remote transport details stay behind one adapter. */
export interface WorktreeConsoleAdapter {
    preflightCreate?(request: {
        sourceSessionId: string;
    }): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreatePreflightResponse>>;
    createWithInitialCommit?(request: {
        sourceSessionId: string;
        confirmationToken: string;
    }): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreateResponse>>;
    sidebarTopology(): Promise<WorktreeConsoleOutcome<WorktreeSidebarTopologyResponse>>;
    current(request: WorktreeConsoleCurrentRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleCurrentResponse>>;
    list(request: WorktreeConsoleListRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleListResponse>>;
    create(request: WorktreeConsoleCreateRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreateResponse>>;
    inspect(request: WorktreeConsoleInspectRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleInspectResponse>>;
    reviewDiff(request: WorktreeConsoleReviewDiffRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleReviewDiffResponse>>;
    preflight(request: WorktreeConsolePreflightRequest): Promise<WorktreeConsoleOutcome<WorktreeConsolePreflightResponse>>;
    previewRecoveryPreflight(request: WorktreeConsolePreviewRecoveryPreflightRequest): Promise<WorktreeConsoleOutcome<WorktreeConsolePreviewRecoveryPreflightResponse>>;
    preparePreviewRecoveryAnalysis(request: WorktreeConsolePreparePreviewRecoveryAnalysisRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    createPreviewRecoveryHandoff(request: WorktreeConsoleCreatePreviewRecoveryHandoffRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleCreatePreviewRecoveryHandoffResponse>>;
    preview(request: WorktreeConsolePreviewRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    checkpoint(request: WorktreeConsoleCheckpointRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    resumeRevision(request: WorktreeConsoleResumeRevisionRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    prepareReviewRegeneration(request: WorktreeConsolePrepareRegenerationRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    rollbackPreview(request: WorktreeConsoleRollbackPreviewRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    discard(request: WorktreeConsoleDiscardRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    finalize(request: WorktreeConsoleFinalizeRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    finalizePreview(request: WorktreeConsoleFinalizePreviewRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    setRetention(request: WorktreeConsoleSetRetentionRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    retryCleanup(request: WorktreeConsoleRetryCleanupRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
    beginNextIteration(request: WorktreeConsoleBeginNextIterationRequest): Promise<WorktreeConsoleOutcome<WorktreeConsoleMutationResponse>>;
}
